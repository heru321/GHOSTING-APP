# 👻 Ghosting — Full Stack Project

Platform TikTok Clone dengan Ghost Hunting features, Token MLC/MSC, Live Streaming, Marketplace, dan AI FYP.

---

## 📁 Struktur Proyek

```
ghosting/
├── frontend/          # Next.js 14 + TypeScript + Tailwind
│   ├── app/           # Pages (App Router)
│   │   ├── page.tsx          ← FYP Feed
│   │   ├── login/            ← OTP Login
│   │   ├── edit/             ← Video Editor + Music Upload
│   │   ├── upload/           ← Upload + Dual Cam + 360°
│   │   ├── live/             ← Live Streaming + Ghost Effects
│   │   ├── profile/          ← User Profile + Coming Soon
│   │   ├── inbox/            ← WA-style Chat
│   │   ├── marketplace/      ← Marketplace + Token
│   │   ├── wallet/           ← MLC/MSC/Rupiah Wallet
│   │   └── admin/            ← Admin Panel + AI Assistant
│   ├── components/
│   │   ├── video/
│   │   │   └── MusicPicker.tsx   ← Library + Upload dari HP
│   │   ├── AuthProvider.tsx
│   │   ├── SocketProvider.tsx
│   │   └── Providers.tsx
│   └── lib/
│       ├── api.ts         ← Axios client + semua endpoint
│       └── musicApi.ts    ← Music upload/list/delete API
│
└── backend/           # Node.js + Express + TypeScript
    ├── src/
    │   ├── app.ts             ← Entry point + Socket.IO
    │   ├── routes/
    │   │   ├── auth.ts        ← OTP login
    │   │   ├── video.ts       ← Upload, FYP, Coming Soon
    │   │   ├── music.ts       ← 🎵 Upload musik dari HP
    │   │   ├── live.ts        ← RTMP streaming
    │   │   ├── chat.ts        ← Realtime chat
    │   │   ├── wallet.ts      ← Token + withdraw
    │   │   ├── marketplace.ts ← Jual beli + fee
    │   │   ├── user.ts        ← Profile + follow
    │   │   ├── admin.ts       ← Admin panel + AI assistant
    │   │   └── ads.ts         ← Iklan berbayar
    │   ├── services/
    │   │   ├── ffmpeg.ts      ← Durasi, merge audio, waveform
    │   │   ├── s3.ts          ← Upload/delete media
    │   │   └── mediaServer.ts ← RTMP Live server
    │   ├── middleware/
    │   │   └── auth.ts        ← JWT authenticate + requireAdmin
    │   └── lib/
    │       └── prisma.ts
    └── prisma/
        └── schema.prisma      ← Full DB schema (User, Video, Music, Live, dll)
```

---

## 🚀 Cara Setup

### 1. Clone & Install

```bash
# Frontend
cd frontend && npm install

# Backend
cd backend && npm install
```

### 2. Setup Database

```bash
# Install PostgreSQL, lalu buat database:
createdb ghosting_db

# Copy env
cp .env.example .env
# Edit DATABASE_URL di .env

# Jalankan migrasi
cd backend
npx prisma migrate dev --name init
npx prisma generate
```

### 3. Setup Environment

```bash
# Backend: isi backend/.env
# - DATABASE_URL
# - JWT_SECRET (generate: openssl rand -base64 64)
# - AWS S3 credentials
# - Twilio untuk OTP SMS
# - Midtrans untuk GoPay
# - OpenAI untuk AI features

# Frontend: isi frontend/.env.local
NEXT_PUBLIC_API_URL=http://localhost:4000/api
NEXT_PUBLIC_SOCKET_URL=http://localhost:4000
```

### 4. Jalankan

```bash
# Terminal 1 — Backend
cd backend && npm run dev

# Terminal 2 — Frontend
cd frontend && npm run dev
```

Buka: http://localhost:3000

---

## 🎵 Fitur Upload Musik dari HP

File: `frontend/components/video/MusicPicker.tsx`

**Tab yang tersedia di Video Editor:**
- **Library** — musik bawaan Ghosting (Ghostly Ambience, Dark Forest, EMF Noise, dll)
- **Milikku** — musik yang sudah diupload user
- **Upload** — upload baru dari HP/komputer

**Format yang didukung:** MP3, WAV, AAC, OGG, FLAC, M4A  
**Batas:** 30 MB, maks. 15 menit

**Flow upload:**
1. User ketuk tab "⬆️ Upload" di music panel editor
2. Drag & drop file atau ketuk area upload
3. Browser baca durasi otomatis
4. Isi judul + artis (opsional)
5. Pilih apakah mau dibagikan ke library publik
6. Klik upload → progress bar real-time
7. Setelah selesai, musik langsung terpilih dan masuk tab "Milikku"

**Backend endpoint:**
```
POST /api/music/upload    ← upload file (multipart)
GET  /api/music           ← list library + milik user
PATCH /api/music/:id      ← edit judul/artis
DELETE /api/music/:id     ← hapus
POST /api/music/:id/use   ← increment usage count
```

---

## 💾 Database Models Utama

| Model | Deskripsi |
|-------|-----------|
| User | Akun user (phone, username, saldo MLC/MSC/Rupiah, wallet) |
| Video | Video upload (360°, dual cam, coming soon, trailer) |
| Music | Musik upload dari HP / library |
| LiveStream | Sesi live + efek ghost |
| Gift | Token yang dikirim saat live |
| Message | Chat WA-style |
| MarketItem | Produk marketplace |
| Withdrawal | Request tarik saldo |
| Ad | Iklan video berbayar |
| SystemFee | Fee admin (configurable) |

---

## 🔑 Fitur Utama

| Fitur | Status |
|-------|--------|
| Login OTP HP | ✅ |
| FYP Feed (AI rekomendasi) | ✅ |
| Live + Ghost Camera (8 efek) | ✅ |
| Token MLC/MSC (Solana) | ✅ |
| Phantom/Trust Wallet | ✅ |
| Video Editor TikTok-style | ✅ |
| Upload Musik dari HP | ✅ |
| 360° Dual Camera Video | ✅ |
| Coming Soon Trailer | ✅ |
| WA-style Inbox Chat | ✅ |
| Marketplace + Fee Admin | ✅ |
| Withdraw (GoPay/Bank) | ✅ |
| Admin Panel Full Control | ✅ |
| AI Assistant Admin | ✅ |
| Generate Gambar/Video (Admin) | ✅ |
| Payment Gateway GoPay | ✅ |

---

## 📦 Tech Stack

**Frontend:** Next.js 14 · TypeScript · Tailwind CSS · Zustand · Socket.io-client · @solana/web3.js · Framer Motion

**Backend:** Node.js · Express · TypeScript · Prisma ORM · PostgreSQL · Redis · Socket.io · FFmpeg · AWS S3 · Twilio · Midtrans · OpenAI
