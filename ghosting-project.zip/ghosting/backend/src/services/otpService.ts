import twilio from 'twilio'

const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

export async function sendSMSOTP(phone: string, code: string): Promise<void> {
  if (process.env.NODE_ENV === 'development') {
    console.log(`📱 DEV OTP for ${phone}: ${code}`)
    return
  }
  await client.messages.create({
    body: `Kode OTP Ghosting kamu: ${code}. Berlaku 5 menit. Jangan bagikan ke siapapun.`,
    from: process.env.TWILIO_PHONE_NUMBER || '+1234567890',
    to: phone,
  })
}
