import axios from 'axios'

const MIDTRANS_BASE = 'https://app.sandbox.midtrans.com/snap/v1'
const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY || ''
const auth = Buffer.from(MIDTRANS_SERVER_KEY + ':').toString('base64')

export async function createGopayPayment(userId: string, amount: number, description: string) {
  try {
    const orderId = `ghosting_${userId}_${Date.now()}`
    const { data } = await axios.post(
      `${MIDTRANS_BASE}/transactions`,
      {
        transaction_details: { order_id: orderId, gross_amount: amount },
        payment_type: 'gopay',
        customer_details: { customer_id: userId },
        item_details: [{ id: 'token', price: amount, quantity: 1, name: description }],
      },
      { headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' } }
    )
    return { orderId, token: data.token, redirectUrl: data.redirect_url }
  } catch (err: any) {
    // In sandbox/dev, return mock
    console.error('GoPay payment error:', err.message)
    return { orderId: `mock_${Date.now()}`, token: 'mock_token', redirectUrl: '#' }
  }
}

export async function verifyPayment(orderId: string) {
  try {
    const { data } = await axios.get(
      `https://api.sandbox.midtrans.com/v2/${orderId}/status`,
      { headers: { Authorization: `Basic ${auth}` } }
    )
    return data.transaction_status === 'settlement' || data.transaction_status === 'capture'
  } catch {
    return false
  }
}

// Webhook handler for Midtrans
export async function handlePaymentWebhook(notification: any) {
  const { order_id, transaction_status, payment_type, gross_amount } = notification
  if (transaction_status === 'settlement' || transaction_status === 'capture') {
    // Parse orderId: ghosting_userId_timestamp
    const parts = order_id.split('_')
    const userId = parts[1]
    // Credit user accordingly
    return { userId, amount: parseInt(gross_amount), status: 'paid' }
  }
  return null
}
