import NodeMediaServer from 'node-media-server'
import { prisma } from '../lib/prisma'
import { io } from '../app'

export function startMediaServer() {
  const nms = new NodeMediaServer({
    rtmp: {
      port: 1935,
      chunk_size: 60000,
      gop_cache: true,
      ping: 30,
      ping_timeout: 60,
    },
    http: {
      port: 8000,
      allow_origin: '*',
    },
  })

  nms.on('prePublish', async (id: string, StreamPath: string, args: any) => {
    console.log('[NodeMediaServer] prePublish', id, StreamPath)
    const streamKey = StreamPath.split('/').pop()
    if (!streamKey) return

    const stream = await prisma.liveStream.findFirst({ where: { streamKey } })
    if (!stream) {
      const session = (nms as any).getSession(id)
      session?.reject()
      console.log('Unauthorized stream key:', streamKey)
    }
  })

  nms.on('postPublish', async (id: string, StreamPath: string) => {
    const streamKey = StreamPath.split('/').pop()
    if (!streamKey) return
    const stream = await prisma.liveStream.findFirst({ where: { streamKey } })
    if (stream) {
      await prisma.liveStream.update({ where: { id: stream.id }, data: { isActive: true } })
      io.emit('live:started', { streamId: stream.id, userId: stream.userId })
      console.log('Live stream started:', stream.id)
    }
  })

  nms.on('donePublish', async (id: string, StreamPath: string) => {
    const streamKey = StreamPath.split('/').pop()
    if (!streamKey) return
    const stream = await prisma.liveStream.findFirst({ where: { streamKey } })
    if (stream) {
      await prisma.liveStream.update({ where: { id: stream.id }, data: { isActive: false, endedAt: new Date() } })
      io.to(`live:${stream.id}`).emit('live:ended', { streamId: stream.id })
      console.log('Live stream ended:', stream.id)
    }
  })

  nms.run()
  console.log('📡 RTMP server on :1935 | HLS on :8000')
}
