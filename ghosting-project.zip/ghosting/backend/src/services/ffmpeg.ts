import ffmpeg from 'fluent-ffmpeg'

/**
 * Dapatkan durasi file audio/video dalam detik
 */
export function getMusicDuration(filePath: string): Promise<number> {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, metadata) => {
      if (err) return reject(err)
      const duration = metadata?.format?.duration ?? 0
      resolve(Number(duration))
    })
  })
}

/**
 * Convert audio ke MP3 standar agar kompatibel di semua device
 */
export function convertToMp3(inputPath: string, outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .audioCodec('libmp3lame')
      .audioBitrate('192k')
      .audioFrequency(44100)
      .audioChannels(2)
      .format('mp3')
      .output(outputPath)
      .on('end', () => resolve())
      .on('error', (err) => reject(err))
      .run()
  })
}

/**
 * Gabungkan audio track ke video (untuk video editor)
 */
export function mergeAudioVideo(
  videoPath: string,
  audioPath: string,
  outputPath: string,
  musicVolume = 0.8,
  origVolume = 0.6
): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg()
      .input(videoPath)
      .input(audioPath)
      .complexFilter([
        `[0:a]volume=${origVolume}[orig]`,
        `[1:a]volume=${musicVolume}[music]`,
        `[orig][music]amix=inputs=2:duration=first[aout]`,
      ])
      .outputOptions(['-map 0:v', '-map [aout]', '-c:v copy', '-c:a aac', '-shortest'])
      .output(outputPath)
      .on('end', () => resolve())
      .on('error', (err) => reject(err))
      .run()
  })
}

/**
 * Generate waveform data (array amplitudo) untuk visualisasi
 */
export function getWaveform(filePath: string, samples = 60): Promise<number[]> {
  return new Promise((resolve, reject) => {
    const amplitudes: number[] = []
    ffmpeg(filePath)
      .audioFilters(`aresample=8000,asetnsamples=${samples}`)
      .format('f32le')
      .output('/dev/null')
      .on('error', reject)
      .on('end', () => {
        // Normalize ke 0–1
        const max = Math.max(...amplitudes, 1)
        resolve(amplitudes.map(v => parseFloat((Math.abs(v) / max).toFixed(3))))
      })
      .run()
  })
}
