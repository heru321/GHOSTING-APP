import { prisma } from '../lib/prisma'

export async function transferToken(
  senderId: string,
  receiverId: string,
  amount: number,
  adminFee: number,
  tokenType: 'MLC' | 'MSC'
) {
  const netAmount = amount - adminFee
  const balanceKey = tokenType === 'MLC' ? 'balanceMLC' : 'balanceMSC'

  await prisma.$transaction([
    // Deduct sender
    prisma.user.update({ where: { id: senderId }, data: { [balanceKey]: { decrement: amount } } }),
    // Credit receiver (net)
    prisma.user.update({ where: { id: receiverId }, data: { [balanceKey]: { increment: netAmount } } }),
    // Log transaction sender
    prisma.transaction.create({ data: { userId: senderId, type: 'gift_sent', amount: -amount, currency: tokenType, description: `Gift sent ${amount} ${tokenType}` } }),
    // Log transaction receiver
    prisma.transaction.create({ data: { userId: receiverId, type: 'gift_received', amount: netAmount, currency: tokenType, description: `Gift received ${netAmount} ${tokenType} (fee: ${adminFee})` } }),
  ])
}

export async function deductFee(userId: string, amount: number, currency: 'IDR' | 'MLC' | 'MSC') {
  const key = currency === 'IDR' ? 'balanceRupiah' : currency === 'MLC' ? 'balanceMLC' : 'balanceMSC'
  return prisma.user.update({ where: { id: userId }, data: { [key]: { decrement: amount } } })
}

export async function addBalance(userId: string, amount: number, currency: 'IDR' | 'MLC' | 'MSC', description: string) {
  const key = currency === 'IDR' ? 'balanceRupiah' : currency === 'MLC' ? 'balanceMLC' : 'balanceMSC'
  return prisma.$transaction([
    prisma.user.update({ where: { id: userId }, data: { [key]: { increment: amount } } }),
    prisma.transaction.create({ data: { userId, type: 'credit', amount, currency, description } }),
  ])
}
