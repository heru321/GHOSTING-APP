import Bull from 'bull'
import ffmpeg from 'fluent-ffmpeg'
import path from 'path'
import fs from 'fs'
import { prisma } from '../lib/prisma'
import { uploadToS3 } from './storageService'

export const processVideoQueue = new Bull('video-processing', {
  redis: { host: process.env.REDIS_HOST || 'localhost', port: 6379 },
})

processVideoQueue.process('process', async (job) => {
  const { videoId, videoUrl, is360, audioEnhanced, isTrailer } = job.data
  console.log(`Processing video ${videoId}...`)

  try {
    const tmpInput = `/tmp/input_${videoId}.mp4`
    const tmpOutput = `/tmp/output_${videoId}.mp4`

    // Download from S3
    const https = require('https')
    await downloadFile(videoUrl, tmpInput)

    // Build ffmpeg command
    let cmd = ffmpeg(tmpInput)

    if (audioEnhanced) {
      // Ghosting Surround: loudnorm + equalizer for cinema effect
      cmd = cmd.audioFilters([
        'loudnorm=I=-16:TP=-1.5:LRA=11',
        'equalizer=f=100:width_type=o:width=2:g=3',
        'equalizer=f=8000:width_type=o:width=2:g=2',
      ])
    }

    if (isTrailer) {
      // Add COMING SOON watermark
      cmd = cmd.videoFilters([
        'drawtext=text=\'COMING SOON\':fontsize=36:fontcolor=white:x=(w-text_w)/2:y=h/2-40:box=1:boxcolor=black@0.5:boxborderw=8',
        'drawtext=text=\'GHOSTING\':fontsize=20:fontcolor=white@0.7:x=(w-text_w)/2:y=h/2+20',
      ])
    }

    await new Promise<void>((resolve, reject) => {
      cmd
        .outputOptions(['-c:v libx264', '-preset fast', '-crf 23', '-c:a aac', '-b:a 128k', '-movflags +faststart'])
        .output(tmpOutput)
        .on('end', resolve)
        .on('error', reject)
        .run()
    })

    // Upload processed video
    const buffer = fs.readFileSync(tmpOutput)
    const key = `processed/${videoId}.mp4`
    const processedUrl = await uploadToS3(buffer, key, 'video/mp4')

    await prisma.video.update({ where: { id: videoId }, data: { videoUrl: processedUrl } })

    // Cleanup
    fs.unlinkSync(tmpInput)
    fs.unlinkSync(tmpOutput)

    console.log(`Video ${videoId} processed successfully`)
    return { videoId, processedUrl }
  } catch (err) {
    console.error(`Video processing failed for ${videoId}:`, err)
    throw err
  }
})

function downloadFile(url: string, dest: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const https = require('https')
    const http = require('http')
    const protocol = url.startsWith('https') ? https : http
    const file = fs.createWriteStream(dest)
    protocol.get(url, (res: any) => {
      res.pipe(file)
      file.on('finish', () => { file.close(); resolve() })
    }).on('error', reject)
  })
}
