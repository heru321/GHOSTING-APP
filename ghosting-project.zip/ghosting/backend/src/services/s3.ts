import AWS from 'aws-sdk'
import fs from 'fs'
import path from 'path'

const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'ap-southeast-1',
})

const BUCKET = process.env.AWS_S3_BUCKET || 'ghosting-media'

export async function uploadToS3(
  filePath: string,
  key: string,
  contentType: string
): Promise<string> {
  const fileStream = fs.createReadStream(filePath)
  const params: AWS.S3.PutObjectRequest = {
    Bucket: BUCKET,
    Key: key,
    Body: fileStream,
    ContentType: contentType,
    ACL: 'public-read',
  }
  const result = await s3.upload(params).promise()
  return result.Location
}

export async function deleteFromS3(key: string): Promise<void> {
  await s3.deleteObject({ Bucket: BUCKET, Key: key }).promise()
}

export async function getSignedUrl(key: string, expiresIn = 3600): Promise<string> {
  return s3.getSignedUrlPromise('getObject', { Bucket: BUCKET, Key: key, Expires: expiresIn })
}
