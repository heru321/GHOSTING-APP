import { Request, Response } from 'express'
import { prisma } from '../lib/prisma'
import { uploadToS3 } from '../services/storageService'
import { processVideoQueue } from '../services/videoProcessor'
import { addDays, addWeeks, addMonths } from 'date-fns'

export async function getFYP(req: Request, res: Response) {
  try {
    const page = parseInt(req.query.page as string) || 1
    const limit = 10
    const skip = (page - 1) * limit

    // AI FYP: mix of popular + personalized (simplified)
    const videos = await prisma.video.findMany({
      where: { isDeleted: false, isExclusive: false },
      include: {
        user: { select: { id: true, username: true, displayName: true, avatar: true } },
        _count: { select: { videoLikes: true, comments: true } },
      },
      orderBy: [{ views: 'desc' }, { createdAt: 'desc' }],
      skip,
      take: limit,
    })

    const userId = (req as any).userId
    const likedIds = userId
      ? (await prisma.videoLike.findMany({ where: { userId, videoId: { in: videos.map(v => v.id) } } })).map(l => l.videoId)
      : []

    res.json({
      videos: videos.map(v => ({
        ...v,
        likes: v._count.videoLikes,
        comments: v._count.comments,
        isLiked: likedIds.includes(v.id),
      })),
      page,
      hasMore: videos.length === limit,
    })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to fetch FYP' })
  }
}

export async function uploadVideo(req: Request, res: Response) {
  try {
    const userId = (req as any).userId
    const files = req.files as { [fieldname: string]: Express.Multer.File[] }
    const videoFile = files?.video?.[0]
    const thumbFile = files?.thumbnail?.[0]

    if (!videoFile) return res.status(400).json({ error: 'Video file required' })

    const {
      title, description, hashtags,
      is360, isDualCam, isExclusive, isTrailer,
      musicId, musicTitle, musicVolume, originalVolume,
      filterName, ghostEffects, audioEnhanced,
    } = req.body

    // Upload to S3
    const videoKey = `videos/${userId}/${Date.now()}.mp4`
    const videoUrl = await uploadToS3(videoFile.buffer, videoKey, 'video/mp4')

    let thumbnailUrl: string | undefined
    if (thumbFile) {
      const thumbKey = `thumbnails/${userId}/${Date.now()}.jpg`
      thumbnailUrl = await uploadToS3(thumbFile.buffer, thumbKey, 'image/jpeg')
    }

    const video = await prisma.video.create({
      data: {
        userId,
        title,
        description,
        hashtags: JSON.parse(hashtags || '[]'),
        videoUrl,
        thumbnailUrl,
        is360: is360 === 'true',
        isDualCam: isDualCam === 'true',
        isExclusive: isExclusive === 'true',
        isTrailer: isTrailer === 'true',
        musicId,
        musicTitle,
        musicVolume: parseFloat(musicVolume || '0.8'),
        originalVolume: parseFloat(originalVolume || '0.6'),
        filterName,
        ghostEffects: JSON.parse(ghostEffects || '[]'),
        audioEnhanced: audioEnhanced !== 'false',
        watermarkText: isTrailer === 'true' ? 'COMING SOON · Ghosting' : undefined,
      },
    })

    // Queue video processing (360 conversion, audio enhance, etc.)
    await processVideoQueue.add('process', { videoId: video.id, videoUrl, is360: is360 === 'true', audioEnhanced: audioEnhanced !== 'false' })

    res.json({ video })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Upload failed' })
  }
}

export async function getVideo(req: Request, res: Response) {
  try {
    const video = await prisma.video.findUnique({
      where: { id: req.params.id, isDeleted: false },
      include: { user: { select: { id: true, username: true, displayName: true, avatar: true, isVerified: true } } },
    })
    if (!video) return res.status(404).json({ error: 'Video not found' })
    await prisma.video.update({ where: { id: video.id }, data: { views: { increment: 1 } } })
    res.json({ video })
  } catch (err) {
    res.status(500).json({ error: 'Failed to get video' })
  }
}

export async function likeVideo(req: Request, res: Response) {
  try {
    const userId = (req as any).userId
    const { id: videoId } = req.params
    const existing = await prisma.videoLike.findUnique({ where: { userId_videoId: { userId, videoId } } })
    if (existing) {
      await prisma.videoLike.delete({ where: { userId_videoId: { userId, videoId } } })
      await prisma.video.update({ where: { id: videoId }, data: { likes: { decrement: 1 } } })
      res.json({ liked: false })
    } else {
      await prisma.videoLike.create({ data: { userId, videoId } })
      await prisma.video.update({ where: { id: videoId }, data: { likes: { increment: 1 } } })
      res.json({ liked: true })
    }
  } catch (err) {
    res.status(500).json({ error: 'Failed to like video' })
  }
}

export async function deleteVideo(req: Request, res: Response) {
  try {
    const userId = (req as any).userId
    const video = await prisma.video.findFirst({ where: { id: req.params.id, userId } })
    if (!video) return res.status(404).json({ error: 'Not found or not owner' })
    await prisma.video.update({ where: { id: req.params.id }, data: { isDeleted: true } })
    res.json({ success: true })
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete' })
  }
}

export async function getUserVideos(req: Request, res: Response) {
  try {
    const user = await prisma.user.findUnique({ where: { username: req.params.username } })
    if (!user) return res.status(404).json({ error: 'User not found' })
    const videos = await prisma.video.findMany({
      where: { userId: user.id, isDeleted: false },
      orderBy: { createdAt: 'desc' },
    })
    res.json({ videos })
  } catch (err) {
    res.status(500).json({ error: 'Failed to get videos' })
  }
}

export async function setComingSoon(req: Request, res: Response) {
  try {
    const userId = (req as any).userId
    const { duration } = req.body // '1d' | '1w' | '1m'
    const videoId = req.params.id

    const video = await prisma.video.findFirst({ where: { id: videoId, userId } })
    if (!video) return res.status(404).json({ error: 'Video not found or not owner' })

    const now = new Date()
    const until = duration === '1d' ? addDays(now, 1) : duration === '1w' ? addWeeks(now, 1) : addMonths(now, 1)

    await prisma.video.update({ where: { id: videoId }, data: { isComingSoon: true, comingSoonUntil: until } })
    await prisma.user.update({ where: { id: userId }, data: { comingSoonVideoId: videoId, comingSoonUntil: until } })

    res.json({ success: true, until })
  } catch (err) {
    res.status(500).json({ error: 'Failed to set coming soon' })
  }
}

export async function getComingSoon(req: Request, res: Response) {
  try {
    const user = await prisma.user.findUnique({
      where: { username: req.params.username },
      include: { videos: { where: { isComingSoon: true, comingSoonUntil: { gt: new Date() } }, take: 1 } },
    })
    if (!user) return res.status(404).json({ error: 'User not found' })
    res.json({ comingSoon: user.videos[0] || null, until: user.comingSoonUntil })
  } catch (err) {
    res.status(500).json({ error: 'Failed to get coming soon' })
  }
}
