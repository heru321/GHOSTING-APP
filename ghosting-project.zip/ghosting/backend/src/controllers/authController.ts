import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import { prisma } from '../lib/prisma'
import { generateOTP, sendSMSOTP } from '../services/otpService'
import { addMinutes, isAfter } from 'date-fns'

export async function sendOTP(req: Request, res: Response) {
  try {
    const { phone } = req.body
    if (!phone) return res.status(400).json({ error: 'Phone required' })

    const normalized = phone.startsWith('+') ? phone : `+62${phone.replace(/^0/, '')}`

    // Invalidate old OTPs
    await prisma.oTPCode.updateMany({
      where: { phone: normalized, used: false },
      data: { used: true },
    })

    const code = generateOTP()
    await prisma.oTPCode.create({
      data: { phone: normalized, code, expiresAt: addMinutes(new Date(), 5) },
    })

    await sendSMSOTP(normalized, code)

    res.json({ message: 'OTP sent', phone: normalized })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to send OTP' })
  }
}

export async function verifyOTP(req: Request, res: Response) {
  try {
    const { phone, otp } = req.body
    if (!phone || !otp) return res.status(400).json({ error: 'Phone and OTP required' })

    const normalized = phone.startsWith('+') ? phone : `+62${phone.replace(/^0/, '')}`

    const record = await prisma.oTPCode.findFirst({
      where: { phone: normalized, code: otp, used: false },
      orderBy: { createdAt: 'desc' },
    })

    if (!record) return res.status(401).json({ error: 'Invalid OTP' })
    if (isAfter(new Date(), record.expiresAt)) return res.status(401).json({ error: 'OTP expired' })

    await prisma.oTPCode.update({ where: { id: record.id }, data: { used: true } })

    // Upsert user
    const username = 'user_' + normalized.replace(/\D/g, '').slice(-8)
    let user = await prisma.user.findUnique({ where: { phone: normalized } })
    if (!user) {
      user = await prisma.user.create({
        data: { phone: normalized, username, displayName: 'Ghost Hunter' },
      })
    }

    const token = jwt.sign(
      { userId: user.id, isAdmin: user.isAdmin },
      process.env.JWT_SECRET || 'ghosting_secret',
      { expiresIn: '30d' }
    )

    res.json({ token, user: sanitizeUser(user) })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Verification failed' })
  }
}

export async function getMe(req: Request, res: Response) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: (req as any).userId },
      include: {
        _count: { select: { followers: true, following: true, videos: true } },
      },
    })
    if (!user) return res.status(404).json({ error: 'User not found' })
    res.json({ user: sanitizeUser(user) })
  } catch (err) {
    res.status(500).json({ error: 'Failed to get user' })
  }
}

export async function connectWallet(req: Request, res: Response) {
  try {
    const { type, address } = req.body
    const data = type === 'phantom' ? { phantomWallet: address } : { trustWallet: address }
    const user = await prisma.user.update({ where: { id: (req as any).userId }, data })
    res.json({ user: sanitizeUser(user) })
  } catch (err) {
    res.status(500).json({ error: 'Failed to connect wallet' })
  }
}

function sanitizeUser(user: any) {
  const { ...safe } = user
  return safe
}
