import { Server, Socket } from 'socket.io'
import jwt from 'jsonwebtoken'
import { prisma } from '../lib/prisma'

export function setupSocketHandlers(io: Server) {
  // Auth middleware for sockets
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token
    if (!token) return next(new Error('Unauthorized'))
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'ghosting_secret') as any
      ;(socket as any).userId = decoded.userId
      ;(socket as any).isAdmin = decoded.isAdmin
      next()
    } catch {
      next(new Error('Invalid token'))
    }
  })

  io.on('connection', async (socket: Socket) => {
    const userId = (socket as any).userId
    console.log(`Socket connected: ${socket.id} (user: ${userId})`)

    // Mark user online
    await prisma.user.update({ where: { id: userId }, data: {} }).catch(() => {})

    // ─── Live stream events ───────────────────────────
    socket.on('live:join', async ({ streamId }) => {
      socket.join(`live:${streamId}`)
      await prisma.liveStream.update({
        where: { id: streamId },
        data: { viewerCount: { increment: 1 } },
      }).catch(() => {})

      const count = (await prisma.liveStream.findUnique({ where: { id: streamId } }))?.viewerCount || 0
      io.to(`live:${streamId}`).emit('live:viewerCount', { count, streamId })

      const user = await prisma.user.findUnique({ where: { id: userId }, select: { displayName: true, username: true } })
      io.to(`live:${streamId}`).emit('live:userJoined', { username: user?.username, streamId })
    })

    socket.on('live:leave', async ({ streamId }) => {
      socket.leave(`live:${streamId}`)
      await prisma.liveStream.update({
        where: { id: streamId },
        data: { viewerCount: { decrement: 1 } },
      }).catch(() => {})

      const count = (await prisma.liveStream.findUnique({ where: { id: streamId } }))?.viewerCount || 0
      io.to(`live:${streamId}`).emit('live:viewerCount', { count, streamId })
    })

    socket.on('live:comment', async ({ streamId, content }) => {
      const user = await prisma.user.findUnique({ where: { id: userId }, select: { username: true, displayName: true } })
      if (!user) return

      await prisma.liveComment.create({ data: { streamId, userId, username: user.username, content } })

      io.to(`live:${streamId}`).emit('live:comment', {
        userId, username: user.username, displayName: user.displayName, content,
        timestamp: new Date().toISOString(),
      })
    })

    // ─── Chat events ──────────────────────────────────
    socket.on('chat:join', ({ conversationId }) => {
      socket.join(`chat:${conversationId}`)
    })

    socket.on('chat:message', async ({ receiverId, content, type = 'text', tokenAmt }) => {
      const message = await prisma.message.create({
        data: { senderId: userId, receiverId, content, type, tokenAmount: tokenAmt },
        include: { sender: { select: { username: true, displayName: true, avatar: true } } },
      })

      // Emit to both sender and receiver
      const conversationId = [userId, receiverId].sort().join('_')
      io.to(`chat:${conversationId}`).emit('chat:message', message)
      io.to(`user:${receiverId}`).emit('chat:notification', {
        from: message.sender.username,
        preview: content,
        messageId: message.id,
      })
    })

    socket.on('chat:typing', ({ receiverId }) => {
      io.to(`user:${receiverId}`).emit('chat:typing', { from: userId })
    })

    // ─── User room (personal notifications) ──────────
    socket.join(`user:${userId}`)

    // ─── Disconnect ───────────────────────────────────
    socket.on('disconnect', () => {
      console.log(`Socket disconnected: ${socket.id}`)
    })
  })
}
