import { Router } from 'express'
import { authMiddleware, adminMiddleware } from '../middleware/auth'
import { prisma } from '../lib/prisma'
import { io } from '../app'
import OpenAI from 'openai'

export const adminRouter = Router()
adminRouter.use(authMiddleware, adminMiddleware)

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

// Dashboard stats
adminRouter.get('/dashboard', async (req, res) => {
  try {
    const [totalUsers, activeStreams, pendingWithdrawals, totalAdsRevenue] = await Promise.all([
      prisma.user.count(),
      prisma.liveStream.count({ where: { isActive: true } }),
      prisma.withdrawal.count({ where: { status: 'pending' } }),
      prisma.ad.aggregate({ where: { status: 'active' }, _sum: { budget: true } }),
    ])

    const adminFees = await prisma.gift.aggregate({ _sum: { adminFee: true } })
    const todayWithdrawFees = await prisma.withdrawal.aggregate({
      where: { status: 'approved', createdAt: { gte: new Date(new Date().setHours(0,0,0,0)) } },
      _sum: { fee: true },
    })

    res.json({
      totalUsers,
      activeStreams,
      adminBalance: (adminFees._sum.adminFee || 0) + (todayWithdrawFees._sum.fee || 0),
      pendingWithdrawals,
      totalAdsRevenue: totalAdsRevenue._sum.budget || 0,
    })
  } catch (err) {
    res.status(500).json({ error: 'Failed to get dashboard' })
  }
})

// Users management
adminRouter.get('/users', async (req, res) => {
  const { page = 1, search = '' } = req.query
  const users = await prisma.user.findMany({
    where: search ? { OR: [{ username: { contains: String(search) } }, { phone: { contains: String(search) } }] } : {},
    skip: (Number(page) - 1) * 20,
    take: 20,
    orderBy: { createdAt: 'desc' },
  })
  res.json({ users })
})

adminRouter.post('/users/:id/suspend', async (req, res) => {
  await prisma.user.update({ where: { id: req.params.id }, data: { isSuspended: true } })
  res.json({ success: true })
})

adminRouter.post('/users/:id/unsuspend', async (req, res) => {
  await prisma.user.update({ where: { id: req.params.id }, data: { isSuspended: false } })
  res.json({ success: true })
})

// Live control
adminRouter.get('/live', async (req, res) => {
  const streams = await prisma.liveStream.findMany({
    where: { isActive: true },
    include: { user: { select: { username: true, displayName: true } } },
  })
  res.json({ streams })
})

adminRouter.post('/live/:id/stop', async (req, res) => {
  await prisma.liveStream.update({ where: { id: req.params.id }, data: { isActive: false, endedAt: new Date() } })
  io.to(`live:${req.params.id}`).emit('live:adminStop', { message: 'Live dihentikan oleh admin' })
  res.json({ success: true })
})

// Fee management
adminRouter.put('/fees', async (req, res) => {
  const fees = req.body as Record<string, number>
  await Promise.all(
    Object.entries(fees).map(([key, value]) =>
      prisma.systemFee.upsert({ where: { key }, update: { value }, create: { key, value } })
    )
  )
  res.json({ success: true })
})

adminRouter.get('/fees', async (req, res) => {
  const fees = await prisma.systemFee.findMany()
  res.json({ fees })
})

// Withdrawals
adminRouter.get('/withdrawals', async (req, res) => {
  const withdrawals = await prisma.withdrawal.findMany({
    where: { status: 'pending' },
    include: { user: { select: { username: true, phone: true } } },
    orderBy: { createdAt: 'asc' },
  })
  res.json({ withdrawals })
})

adminRouter.post('/withdrawals/:id/approve', async (req, res) => {
  const w = await prisma.withdrawal.update({
    where: { id: req.params.id },
    data: { status: 'approved', processedAt: new Date() },
  })
  io.to(`user:${w.userId}`).emit('withdrawal:approved', { amount: w.netAmount, method: w.method })
  res.json({ success: true })
})

adminRouter.post('/withdrawals/:id/reject', async (req, res) => {
  const w = await prisma.withdrawal.findUnique({ where: { id: req.params.id } })
  if (!w) return res.status(404).json({ error: 'Not found' })
  await prisma.withdrawal.update({ where: { id: req.params.id }, data: { status: 'rejected' } })
  // Refund
  await prisma.user.update({ where: { id: w.userId }, data: { balanceRupiah: { increment: w.amount } } })
  io.to(`user:${w.userId}`).emit('withdrawal:rejected', { amount: w.amount })
  res.json({ success: true })
})

// Generate image (admin only — calls OpenAI DALL·E)
adminRouter.post('/generate/image', async (req, res) => {
  try {
    const { prompt, style = 'realistic' } = req.body
    const fullPrompt = `${prompt}, ${style} style, high quality, cinematic lighting`

    const response = await openai.images.generate({
      model: 'dall-e-3',
      prompt: fullPrompt,
      n: 1,
      size: '1024x1024',
      quality: 'standard',
    })

    res.json({ url: response.data[0].url, prompt: fullPrompt })
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Image generation failed' })
  }
})

// Generate video prompt (admin only — uses OpenAI to create video script / prompts)
adminRouter.post('/generate/video', async (req, res) => {
  try {
    const { prompt, duration, resolution } = req.body
    // In production: integrate with Runway ML, Sora, or similar
    // Here we generate a detailed script/storyboard via GPT
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'Kamu adalah AI video generator untuk platform Ghosting. Buat storyboard detail untuk video yang diminta admin.' },
        { role: 'user', content: `Buat video: "${prompt}". Durasi: ${duration} detik. Resolusi: ${resolution}. Berikan shot-by-shot storyboard detail.` },
      ],
      max_tokens: 1000,
    })
    res.json({
      storyboard: completion.choices[0].message.content,
      prompt, duration, resolution,
      status: 'processing',
      note: 'Integrasikan dengan Runway ML / Sora untuk generate video nyata',
    })
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Video generation failed' })
  }
})

// AI Assistant — website maintenance chatbot
adminRouter.post('/ai-assistant', async (req, res) => {
  try {
    const { prompt, history = [] } = req.body

    const systemPrompt = `Kamu adalah AI Assistant untuk platform Ghosting — sebuah TikTok clone dengan fitur ghost hunting.
Kamu memiliki akses PENUH ke seluruh sistem website Ghosting dan dapat:
- Mendiagnosis dan memperbaiki bug secara otomatis
- Menambahkan fitur baru tanpa merusak yang lama
- Membuat halaman baru dengan kode lengkap
- Mengatur user, payment fee, sistem
- Melakukan deployment perubahan ke live site
- Menganalisis performa dan memberikan rekomendasi

Saat kamu menerima perintah, berikan:
1. Analisis masalah / permintaan
2. Action plan step-by-step
3. Kode yang dihasilkan (jika perlu)
4. Status eksekusi
5. Konfirmasi hasil

Selalu gunakan Bahasa Indonesia. Berikan respons yang teknis tapi mudah dipahami admin.`

    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      { role: 'system', content: systemPrompt },
      ...history.map((h: any) => ({ role: h.role as 'user' | 'assistant', content: h.content })),
      { role: 'user', content: prompt },
    ]

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages,
      max_tokens: 2000,
      temperature: 0.7,
    })

    res.json({ reply: completion.choices[0].message.content })
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'AI assistant failed' })
  }
})
