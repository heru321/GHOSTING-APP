import { Router } from 'express'
import { authMiddleware } from '../middleware/auth'
import { prisma } from '../lib/prisma'
import { io } from '../app'
import { deductFee, transferToken } from '../services/walletService'

export const liveRouter = Router()

// Start live
liveRouter.post('/start', authMiddleware, async (req, res) => {
  try {
    const userId = (req as any).userId
    const { title, effects = [] } = req.body
    const streamKey = `live_${userId}_${Date.now()}`
    const rtmpUrl = `rtmp://${process.env.RTMP_HOST || 'localhost'}:1935/live/${streamKey}`
    const hlsUrl = `http://${process.env.RTMP_HOST || 'localhost'}:8000/live/${streamKey}/index.m3u8`

    const stream = await prisma.liveStream.create({
      data: { userId, title, streamKey, rtmpUrl, hlsUrl, effects },
    })

    io.emit('live:new', { streamId: stream.id, userId, title })
    res.json({ stream, streamKey, rtmpUrl, hlsUrl })
  } catch (err) {
    res.status(500).json({ error: 'Failed to start live' })
  }
})

// End live
liveRouter.post('/:id/end', authMiddleware, async (req, res) => {
  try {
    const stream = await prisma.liveStream.update({
      where: { id: req.params.id },
      data: { isActive: false, endedAt: new Date() },
    })
    io.to(`live:${req.params.id}`).emit('live:ended', { streamId: req.params.id })
    res.json({ stream })
  } catch (err) {
    res.status(500).json({ error: 'Failed to end live' })
  }
})

// Get active streams
liveRouter.get('/active', async (req, res) => {
  try {
    const streams = await prisma.liveStream.findMany({
      where: { isActive: true },
      include: { user: { select: { username: true, displayName: true, avatar: true } } },
      orderBy: { viewerCount: 'desc' },
    })
    res.json({ streams })
  } catch (err) {
    res.status(500).json({ error: 'Failed to get streams' })
  }
})

// Get stream by id
liveRouter.get('/:id', async (req, res) => {
  try {
    const stream = await prisma.liveStream.findUnique({
      where: { id: req.params.id },
      include: { user: { select: { username: true, displayName: true, avatar: true } } },
    })
    if (!stream) return res.status(404).json({ error: 'Stream not found' })
    res.json({ stream })
  } catch (err) {
    res.status(500).json({ error: 'Failed to get stream' })
  }
})

// Send gift (token)
liveRouter.post('/:id/gift', authMiddleware, async (req, res) => {
  try {
    const senderId = (req as any).userId
    const { amount, tokenType = 'MLC' } = req.body
    const streamId = req.params.id

    const stream = await prisma.liveStream.findUnique({
      where: { id: streamId },
      include: { user: true },
    })
    if (!stream) return res.status(404).json({ error: 'Stream not found' })

    const sender = await prisma.user.findUnique({ where: { id: senderId } })
    if (!sender) return res.status(404).json({ error: 'Sender not found' })

    // Get fee from system settings
    const feeSetting = await prisma.systemFee.findUnique({ where: { key: 'live_fee_percent' } })
    const feePercent = feeSetting?.value ?? 15
    const adminFee = (amount * feePercent) / 100
    const netAmount = amount - adminFee

    // Check balance
    const balanceKey = tokenType === 'MLC' ? 'balanceMLC' : 'balanceMSC'
    if ((sender as any)[balanceKey] < amount) return res.status(400).json({ error: 'Insufficient balance' })

    // Deduct sender, credit receiver (net), credit admin (fee)
    await transferToken(senderId, stream.userId, amount, adminFee, tokenType as 'MLC' | 'MSC')

    const gift = await prisma.gift.create({
      data: { senderId, receiverId: stream.userId, streamId, amount, tokenType, adminFee },
    })

    await prisma.liveStream.update({
      where: { id: streamId },
      data: { totalTokens: { increment: amount } },
    })

    // Emit to live room
    io.to(`live:${streamId}`).emit('live:gift', {
      senderId, senderName: sender.displayName, amount, tokenType, streamId,
    })

    res.json({ gift })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to send gift' })
  }
})
