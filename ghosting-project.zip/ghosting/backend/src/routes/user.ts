import { Router } from 'express'
import multer from 'multer'
import { authMiddleware } from '../middleware/auth'
import { prisma } from '../lib/prisma'
import { uploadToS3 } from '../services/storageService'

const upload = multer({ storage: multer.memoryStorage() })
export const userRouter = Router()

userRouter.get('/:username', async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { username: req.params.username },
      include: {
        _count: { select: { followers: true, following: true, videos: true } },
        videos: { where: { isDeleted: false }, orderBy: { createdAt: 'desc' }, take: 12 },
      },
    })
    if (!user) return res.status(404).json({ error: 'User not found' })
    if (user.isSuspended) return res.status(403).json({ error: 'Account suspended' })
    res.json({ user })
  } catch (err) { res.status(500).json({ error: 'Failed' }) }
})

userRouter.put('/profile', authMiddleware, upload.single('avatar'), async (req, res) => {
  try {
    const userId = (req as any).userId
    const { displayName, bio } = req.body
    let avatar: string | undefined
    if (req.file) {
      avatar = await uploadToS3(req.file.buffer, `avatars/${userId}.jpg`, req.file.mimetype)
    }
    const user = await prisma.user.update({
      where: { id: userId },
      data: { ...(displayName && { displayName }), ...(bio !== undefined && { bio }), ...(avatar && { avatar }) },
    })
    res.json({ user })
  } catch (err) { res.status(500).json({ error: 'Failed to update profile' }) }
})

userRouter.post('/:username/follow', authMiddleware, async (req, res) => {
  try {
    const followerId = (req as any).userId
    const target = await prisma.user.findUnique({ where: { username: req.params.username } })
    if (!target) return res.status(404).json({ error: 'User not found' })
    await prisma.follow.create({ data: { followerId, followingId: target.id } })
    res.json({ success: true })
  } catch (err: any) {
    if (err.code === 'P2002') return res.status(400).json({ error: 'Already following' })
    res.status(500).json({ error: 'Failed' })
  }
})

userRouter.delete('/:username/follow', authMiddleware, async (req, res) => {
  try {
    const followerId = (req as any).userId
    const target = await prisma.user.findUnique({ where: { username: req.params.username } })
    if (!target) return res.status(404).json({ error: 'User not found' })
    await prisma.follow.deleteMany({ where: { followerId, followingId: target.id } })
    res.json({ success: true })
  } catch (err) { res.status(500).json({ error: 'Failed' }) }
})
