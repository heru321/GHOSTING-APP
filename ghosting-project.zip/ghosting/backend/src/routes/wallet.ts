import { Router } from 'express'
import { authMiddleware } from '../middleware/auth'
import { prisma } from '../lib/prisma'
import { addBalance } from '../services/walletService'
import { createGopayPayment } from '../services/paymentService'

export const walletRouter = Router()
walletRouter.use(authMiddleware)

walletRouter.get('/balance', async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: (req as any).userId },
      select: { balanceMLC: true, balanceMSC: true, balanceRupiah: true, phantomWallet: true, trustWallet: true },
    })
    res.json({ balance: user })
  } catch (err) { res.status(500).json({ error: 'Failed' }) }
})

walletRouter.post('/buy-token', async (req, res) => {
  try {
    const userId = (req as any).userId
    const { type, amount, method } = req.body

    const feeSetting = await prisma.systemFee.findUnique({ where: { key: `${type.toLowerCase()}_price_idr` } })
    const pricePerToken = feeSetting?.value ?? (type === 'MLC' ? 500 : 250)
    const totalIdr = amount * pricePerToken

    // Create payment
    const payment = await createGopayPayment(userId, totalIdr, `Beli ${amount} ${type}`)

    // In real app: wait for payment webhook, then credit tokens
    // For now simulate success
    await addBalance(userId, amount, type as 'MLC' | 'MSC', `Beli ${amount} ${type} via ${method}`)

    res.json({ success: true, amount, type, totalIdr, payment })
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to buy token' })
  }
})

walletRouter.post('/withdraw', async (req, res) => {
  try {
    const userId = (req as any).userId
    const { amount, method, accountNo } = req.body

    const feeSetting = await prisma.systemFee.findUnique({ where: { key: 'withdraw_fee_idr' } })
    const fee = feeSetting?.value ?? 2500
    const minWithdraw = 50000

    if (amount < minWithdraw) return res.status(400).json({ error: `Minimum withdraw Rp ${minWithdraw.toLocaleString()}` })

    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user || user.balanceRupiah < amount) return res.status(400).json({ error: 'Insufficient balance' })

    const netAmount = amount - fee

    // Deduct balance
    await prisma.user.update({ where: { id: userId }, data: { balanceRupiah: { decrement: amount } } })

    const withdrawal = await prisma.withdrawal.create({
      data: { userId, amount, fee, netAmount, method, accountNo, status: 'pending' },
    })

    res.json({ withdrawal, message: 'Permintaan withdraw dikirim, proses 1-2 jam kerja' })
  } catch (err) {
    res.status(500).json({ error: 'Withdraw failed' })
  }
})

walletRouter.get('/transactions', async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1
    const transactions = await prisma.transaction.findMany({
      where: { userId: (req as any).userId },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * 20,
      take: 20,
    })
    res.json({ transactions })
  } catch (err) {
    res.status(500).json({ error: 'Failed' })
  }
})
