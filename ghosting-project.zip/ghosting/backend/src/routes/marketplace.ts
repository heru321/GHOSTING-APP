// marketplace.ts
import { Router } from 'express'
import multer from 'multer'
import { authMiddleware } from '../middleware/auth'
import { prisma } from '../lib/prisma'
import { uploadToS3 } from '../services/storageService'
import { deductFee } from '../services/walletService'

const upload = multer({ storage: multer.memoryStorage() })

export const marketRouter = Router()

marketRouter.get('/', async (req, res) => {
  const { category } = req.query
  const items = await prisma.marketItem.findMany({
    where: { isActive: true, ...(category ? { category: String(category) } : {}) },
    include: { seller: { select: { username: true, displayName: true, avatar: true } } },
    orderBy: { createdAt: 'desc' },
  })
  res.json({ items })
})

marketRouter.post('/', authMiddleware, upload.array('images', 5), async (req, res) => {
  try {
    const sellerId = (req as any).userId
    const { name, description, price, currency = 'IDR', category, stock = 1 } = req.body
    const files = req.files as Express.Multer.File[]
    const images: string[] = []
    for (const f of files || []) {
      const url = await uploadToS3(f.buffer, `market/${sellerId}/${Date.now()}_${f.originalname}`, f.mimetype)
      images.push(url)
    }
    const feeSetting = await prisma.systemFee.findUnique({ where: { key: 'marketplace_fee_percent' } })
    const feePercent = feeSetting?.value ?? 5
    const item = await prisma.marketItem.create({ data: { sellerId, name, description, price: parseFloat(price), currency, category, stock: parseInt(stock), images, adminFee: feePercent } })
    res.json({ item })
  } catch (err) { res.status(500).json({ error: 'Failed to create listing' }) }
})

marketRouter.post('/:id/buy', authMiddleware, async (req, res) => {
  try {
    const buyerId = (req as any).userId
    const item = await prisma.marketItem.findUnique({ where: { id: req.params.id }, include: { seller: true } })
    if (!item || !item.isActive || item.stock < 1) return res.status(400).json({ error: 'Item not available' })

    const feeAmount = (item.price * item.adminFee) / 100
    const sellerAmount = item.price - feeAmount

    // Deduct buyer
    await deductFee(buyerId, item.price, item.currency as any)
    // Credit seller (net)
    await prisma.user.update({ where: { id: item.sellerId }, data: { balanceRupiah: { increment: sellerAmount } } })
    // Decrement stock
    await prisma.marketItem.update({ where: { id: item.id }, data: { stock: { decrement: 1 } } })

    const order = await prisma.order.create({ data: { buyerId, itemId: item.id, amount: item.price, adminFee: feeAmount, status: 'completed' } })
    res.json({ order })
  } catch (err: any) { res.status(500).json({ error: err.message || 'Purchase failed' }) }
})
