import { Router } from 'express'
import { sendOTP, verifyOTP, getMe, connectWallet } from '../controllers/authController'
import { authMiddleware } from '../middleware/auth'

export const authRouter = Router()

authRouter.post('/send-otp', sendOTP)
authRouter.post('/verify-otp', verifyOTP)
authRouter.get('/me', authMiddleware, getMe)
authRouter.post('/connect-wallet', authMiddleware, connectWallet)
