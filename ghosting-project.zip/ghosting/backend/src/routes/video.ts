import { Router } from 'express'
import multer from 'multer'
import { authMiddleware } from '../middleware/auth'
import {
  getFYP, uploadVideo, getVideo, likeVideo,
  deleteVideo, getUserVideos, setComingSoon, getComingSoon,
} from '../controllers/videoController'

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 500 * 1024 * 1024 } })

export const videoRouter = Router()

videoRouter.get('/fyp', authMiddleware, getFYP)
videoRouter.get('/user/:username', getUserVideos)
videoRouter.get('/:id', getVideo)
videoRouter.post('/upload', authMiddleware, upload.fields([
  { name: 'video', maxCount: 1 },
  { name: 'thumbnail', maxCount: 1 },
]), uploadVideo)
videoRouter.post('/:id/like', authMiddleware, likeVideo)
videoRouter.delete('/:id', authMiddleware, deleteVideo)
videoRouter.post('/:id/coming-soon', authMiddleware, setComingSoon)
videoRouter.get('/coming-soon/:username', getComingSoon)
