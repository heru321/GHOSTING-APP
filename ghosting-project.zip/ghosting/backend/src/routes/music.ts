import { Router, Request, Response } from 'express'
import multer from 'multer'
import path from 'path'
import fs from 'fs'
import { prisma } from '../lib/prisma'
import { authenticate } from '../middleware/auth'
import { uploadToS3, deleteFromS3 } from '../services/s3'
import { getMusicDuration } from '../services/ffmpeg'

export const musicRouter = Router()

// ─── Multer config — terima audio saja ───────────────
const storage = multer.diskStorage({
  destination: (_, __, cb) => {
    const dir = '/tmp/ghosting_music'
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    cb(null, dir)
  },
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname)
    cb(null, `music_${Date.now()}${ext}`)
  },
})

const ALLOWED_AUDIO = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/aac', 'audio/flac', 'audio/x-m4a', 'audio/mp4']
const MAX_MUSIC_SIZE = 30 * 1024 * 1024 // 30 MB

const upload = multer({
  storage,
  limits: { fileSize: MAX_MUSIC_SIZE },
  fileFilter: (_, file, cb) => {
    if (ALLOWED_AUDIO.includes(file.mimetype)) cb(null, true)
    else cb(new Error('Format audio tidak didukung. Gunakan MP3, WAV, AAC, atau OGG.'))
  },
})

// ─── GET /api/music — library publik + milik user ────
musicRouter.get('/', authenticate, async (req: Request, res: Response) => {
  try {
    const { search = '', source = '' } = req.query as Record<string, string>
    const userId = (req as any).user.id

    const where: any = {
      OR: [
        { isPublic: true },
        { userId },
      ],
      isPublic: source === 'mine' ? undefined : undefined,
    }

    if (source === 'mine') {
      where.OR = undefined
      where.userId = userId
    } else if (source === 'library') {
      where.OR = undefined
      where.isPublic = true
      where.source = 'library'
    }

    if (search) {
      where.AND = [
        { OR: [{ title: { contains: search, mode: 'insensitive' } }, { artist: { contains: search, mode: 'insensitive' } }] },
      ]
    }

    const music = await prisma.music.findMany({
      where,
      orderBy: [{ usageCount: 'desc' }, { createdAt: 'desc' }],
      take: 50,
      select: {
        id: true, title: true, artist: true, fileUrl: true,
        duration: true, coverUrl: true, isPublic: true,
        source: true, usageCount: true, mimeType: true,
        user: { select: { username: true, displayName: true } },
        createdAt: true,
      },
    })

    res.json({ music })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Gagal mengambil daftar musik' })
  }
})

// ─── POST /api/music/upload — upload dari HP ─────────
musicRouter.post('/upload', authenticate, upload.single('audio'), async (req: Request, res: Response) => {
  const file = req.file
  if (!file) return res.status(400).json({ error: 'File audio tidak ditemukan' })

  const userId = (req as any).user.id
  const { title, artist, isPublic = 'false' } = req.body

  try {
    // 1. Dapatkan durasi dengan ffmpeg
    let duration = 0
    try {
      duration = await getMusicDuration(file.path)
    } catch {
      duration = 0
    }

    // Validasi durasi maksimal 15 menit
    if (duration > 900) {
      fs.unlinkSync(file.path)
      return res.status(400).json({ error: 'Durasi musik maksimal 15 menit' })
    }

    // 2. Upload ke S3
    const s3Key = `music/${userId}/${Date.now()}_${file.filename}`
    const fileUrl = await uploadToS3(file.path, s3Key, file.mimetype)

    // 3. Hapus file temp
    fs.unlinkSync(file.path)

    // 4. Simpan ke DB
    const music = await prisma.music.create({
      data: {
        userId,
        title: title || file.originalname.replace(/\.[^.]+$/, ''),
        artist: artist || null,
        fileUrl,
        duration,
        isPublic: isPublic === 'true',
        source: 'upload',
        fileSize: file.size,
        mimeType: file.mimetype,
      },
      include: {
        user: { select: { username: true, displayName: true } },
      },
    })

    res.status(201).json({ music, message: 'Musik berhasil diupload!' })
  } catch (err) {
    console.error(err)
    if (file?.path && fs.existsSync(file.path)) fs.unlinkSync(file.path)
    res.status(500).json({ error: 'Gagal mengupload musik' })
  }
})

// ─── PATCH /api/music/:id — edit judul/artist ────────
musicRouter.patch('/:id', authenticate, async (req: Request, res: Response) => {
  const userId = (req as any).user.id
  const { title, artist, isPublic } = req.body

  try {
    const existing = await prisma.music.findFirst({ where: { id: req.params.id, userId } })
    if (!existing) return res.status(404).json({ error: 'Musik tidak ditemukan' })

    const updated = await prisma.music.update({
      where: { id: req.params.id },
      data: {
        ...(title !== undefined && { title }),
        ...(artist !== undefined && { artist }),
        ...(isPublic !== undefined && { isPublic: Boolean(isPublic) }),
      },
    })

    res.json({ music: updated })
  } catch {
    res.status(500).json({ error: 'Gagal memperbarui musik' })
  }
})

// ─── DELETE /api/music/:id ────────────────────────────
musicRouter.delete('/:id', authenticate, async (req: Request, res: Response) => {
  const userId = (req as any).user.id

  try {
    const music = await prisma.music.findFirst({ where: { id: req.params.id, userId } })
    if (!music) return res.status(404).json({ error: 'Musik tidak ditemukan atau bukan milikmu' })

    // Hapus dari S3
    try {
      const s3Key = music.fileUrl.split('.amazonaws.com/')[1]
      if (s3Key) await deleteFromS3(s3Key)
    } catch (e) {
      console.warn('S3 delete warning:', e)
    }

    await prisma.music.delete({ where: { id: req.params.id } })
    res.json({ message: 'Musik dihapus' })
  } catch {
    res.status(500).json({ error: 'Gagal menghapus musik' })
  }
})

// ─── POST /api/music/:id/use — increment usage count ─
musicRouter.post('/:id/use', authenticate, async (req: Request, res: Response) => {
  try {
    await prisma.music.update({
      where: { id: req.params.id },
      data: { usageCount: { increment: 1 } },
    })
    res.json({ ok: true })
  } catch {
    res.status(500).json({ error: 'Gagal update usage' })
  }
})
