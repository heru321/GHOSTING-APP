import { Router } from 'express'
import multer from 'multer'
import { authMiddleware } from '../middleware/auth'
import { prisma } from '../lib/prisma'
import { createGopayPayment } from '../services/paymentService'
import { uploadToS3 } from '../services/storageService'
import { addDays } from 'date-fns'

const upload = multer({ storage: multer.memoryStorage() })
export const adsRouter = Router()
adsRouter.use(authMiddleware)

adsRouter.post('/', upload.single('video'), async (req, res) => {
  try {
    const userId = (req as any).userId
    const { title, budget, method, days = 7 } = req.body
    let videoUrl: string | undefined
    if (req.file) {
      videoUrl = await uploadToS3(req.file.buffer, `ads/${userId}/${Date.now()}.mp4`, req.file.mimetype)
    }
    const ad = await prisma.ad.create({ data: { userId, title, videoUrl, budget: parseFloat(budget), method, status: 'pending' } })
    res.json({ ad })
  } catch (err) { res.status(500).json({ error: 'Failed to create ad' }) }
})

adsRouter.post('/:id/pay', async (req, res) => {
  try {
    const { method } = req.body
    const ad = await prisma.ad.findUnique({ where: { id: req.params.id } })
    if (!ad) return res.status(404).json({ error: 'Ad not found' })

    const payment = await createGopayPayment(ad.userId, ad.budget, `Iklan: ${ad.title}`)

    // In real: wait webhook. For demo, mark active
    const now = new Date()
    await prisma.ad.update({
      where: { id: ad.id },
      data: { status: 'active', startDate: now, endDate: addDays(now, 7) },
    })

    res.json({ payment, message: 'Iklan aktif! Dana masuk ke saldo admin.' })
  } catch (err) { res.status(500).json({ error: 'Payment failed' }) }
})

adsRouter.get('/mine', async (req, res) => {
  const ads = await prisma.ad.findMany({ where: { userId: (req as any).userId }, orderBy: { createdAt: 'desc' } })
  res.json({ ads })
})
