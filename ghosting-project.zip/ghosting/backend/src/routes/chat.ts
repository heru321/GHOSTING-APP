// ─── chat.ts ─────────────────────────────────────────────────────
import { Router } from 'express'
import { authMiddleware } from '../middleware/auth'
import { prisma } from '../lib/prisma'

export const chatRouter = Router()
chatRouter.use(authMiddleware)

chatRouter.get('/conversations', async (req, res) => {
  const userId = (req as any).userId
  const messages = await prisma.message.findMany({
    where: { OR: [{ senderId: userId }, { receiverId: userId }] },
    include: { sender: { select: { id: true, username: true, displayName: true, avatar: true } }, receiver: { select: { id: true, username: true, displayName: true, avatar: true } } },
    orderBy: { createdAt: 'desc' },
    distinct: ['senderId', 'receiverId'],
  })
  res.json({ conversations: messages })
})

chatRouter.get('/messages/:userId', async (req, res) => {
  const myId = (req as any).userId
  const otherId = req.params.userId
  const page = parseInt(req.query.page as string) || 1
  const messages = await prisma.message.findMany({
    where: { OR: [{ senderId: myId, receiverId: otherId }, { senderId: otherId, receiverId: myId }] },
    orderBy: { createdAt: 'desc' },
    skip: (page - 1) * 30,
    take: 30,
  })
  await prisma.message.updateMany({ where: { receiverId: myId, senderId: otherId, isRead: false }, data: { isRead: true } })
  res.json({ messages: messages.reverse() })
})

chatRouter.post('/messages/:userId', async (req, res) => {
  const senderId = (req as any).userId
  const receiverId = req.params.userId
  const { content, type = 'text', tokenAmt } = req.body
  const message = await prisma.message.create({ data: { senderId, receiverId, content, type, tokenAmount: tokenAmt } })
  res.json({ message })
})
