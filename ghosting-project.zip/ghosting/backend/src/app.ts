import express from 'express'
import http from 'http'
import { Server as SocketServer } from 'socket.io'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import dotenv from 'dotenv'
import { prisma } from './lib/prisma'
import { authRouter } from './routes/auth'
import { videoRouter } from './routes/video'
import { liveRouter } from './routes/live'
import { chatRouter } from './routes/chat'
import { walletRouter } from './routes/wallet'
import { marketRouter } from './routes/marketplace'
import { userRouter } from './routes/user'
import { adminRouter } from './routes/admin'
import { adsRouter } from './routes/ads'
import { musicRouter } from './routes/music'
import { setupSocketHandlers } from './socket/handlers'
import { startMediaServer } from './services/mediaServer'

dotenv.config()

const app = express()
const server = http.createServer(app)

const io = new SocketServer(server, {
  cors: { origin: process.env.FRONTEND_URL || 'http://localhost:3000', credentials: true },
  transports: ['websocket', 'polling'],
})

// ─── Middleware ───────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: false }))
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000', credentials: true }))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, message: 'Too many requests' })
app.use('/api/', limiter)

// ─── Routes ──────────────────────────────────────────
app.use('/api/auth', authRouter)
app.use('/api/videos', videoRouter)
app.use('/api/live', liveRouter)
app.use('/api/chat', chatRouter)
app.use('/api/wallet', walletRouter)
app.use('/api/marketplace', marketRouter)
app.use('/api/users', userRouter)
app.use('/api/admin', adminRouter)
app.use('/api/ads', adsRouter)
app.use('/api/music', musicRouter)

app.get('/health', (_, res) => res.json({ status: 'ok', timestamp: new Date() }))

// ─── Socket.IO ───────────────────────────────────────
setupSocketHandlers(io)

// ─── Error handler ───────────────────────────────────
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err.stack)
  res.status(500).json({ error: 'Internal server error' })
})

// ─── Start ───────────────────────────────────────────
const PORT = process.env.PORT || 4000
server.listen(PORT, async () => {
  console.log(`🚀 Ghosting API running on port ${PORT}`)
  await prisma.$connect()
  console.log('✅ Database connected')
  startMediaServer()
  console.log('📡 RTMP media server started')
})

export { io }
