import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'

export function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'No token' })
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'ghosting_secret') as any
    ;(req as any).userId = decoded.userId
    ;(req as any).isAdmin = decoded.isAdmin
    next()
  } catch {
    res.status(401).json({ error: 'Invalid token' })
  }
}

export function adminMiddleware(req: Request, res: Response, next: NextFunction) {
  if (!(req as any).isAdmin) return res.status(403).json({ error: 'Admin only' })
  next()
}
