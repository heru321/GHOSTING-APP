import axios from 'axios'
import Cookies from 'js-cookie'

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api',
  timeout: 15000,
})

api.interceptors.request.use((config) => {
  const token = Cookies.get('ghosting_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      Cookies.remove('ghosting_token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// ─── Auth ────────────────────────────────────────────
export const authApi = {
  sendOTP: (phone: string) => api.post('/auth/send-otp', { phone }),
  verifyOTP: (phone: string, otp: string) => api.post('/auth/verify-otp', { phone, otp }),
  me: () => api.get('/auth/me'),
  connectWallet: (type: 'phantom' | 'trust', address: string) =>
    api.post('/auth/connect-wallet', { type, address }),
}

// ─── Video ───────────────────────────────────────────
export const videoApi = {
  getFYP: (page = 1) => api.get(`/videos/fyp?page=${page}`),
  upload: (formData: FormData) =>
    api.post('/videos/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  getById: (id: string) => api.get(`/videos/${id}`),
  like: (id: string) => api.post(`/videos/${id}/like`),
  delete: (id: string) => api.delete(`/videos/${id}`),
  getUserVideos: (username: string) => api.get(`/videos/user/${username}`),
  setComingSoon: (id: string, duration: '1d' | '1w' | '1m') =>
    api.post(`/videos/${id}/coming-soon`, { duration }),
}

// ─── Live ────────────────────────────────────────────
export const liveApi = {
  start: (payload: { title: string; effects: string[] }) => api.post('/live/start', payload),
  end: (streamId: string) => api.post(`/live/${streamId}/end`),
  getActive: () => api.get('/live/active'),
  getById: (id: string) => api.get(`/live/${id}`),
  sendGift: (streamId: string, amount: number, tokenType: 'MLC' | 'MSC') =>
    api.post(`/live/${streamId}/gift`, { amount, tokenType }),
  getComment: (streamId: string) => api.get(`/live/${streamId}/comments`),
}

// ─── Chat ────────────────────────────────────────────
export const chatApi = {
  getConversations: () => api.get('/chat/conversations'),
  getMessages: (userId: string, page = 1) =>
    api.get(`/chat/messages/${userId}?page=${page}`),
  sendMessage: (userId: string, content: string, type: 'text' | 'token' = 'text', tokenAmt?: number) =>
    api.post(`/chat/messages/${userId}`, { content, type, tokenAmt }),
}

// ─── Marketplace ─────────────────────────────────────
export const marketApi = {
  list: (category?: string) => api.get(`/marketplace?category=${category || ''}`),
  create: (data: FormData) =>
    api.post('/marketplace', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  buy: (id: string) => api.post(`/marketplace/${id}/buy`),
  getById: (id: string) => api.get(`/marketplace/${id}`),
}

// ─── Wallet ──────────────────────────────────────────
export const walletApi = {
  getBalance: () => api.get('/wallet/balance'),
  buyToken: (type: 'MLC' | 'MSC', amount: number, method: 'gopay' | 'googlepay') =>
    api.post('/wallet/buy-token', { type, amount, method }),
  withdraw: (amount: number, method: 'gopay' | 'bank' | 'ovo', accountNo: string) =>
    api.post('/wallet/withdraw', { amount, method, accountNo }),
  getTransactions: (page = 1) => api.get(`/wallet/transactions?page=${page}`),
}

// ─── User / Profile ──────────────────────────────────
export const userApi = {
  getProfile: (username: string) => api.get(`/users/${username}`),
  updateProfile: (data: { displayName?: string; bio?: string; avatar?: File }) => {
    const fd = new FormData()
    Object.entries(data).forEach(([k, v]) => v && fd.append(k, v as string | Blob))
    return api.put('/users/profile', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  follow: (username: string) => api.post(`/users/${username}/follow`),
  unfollow: (username: string) => api.delete(`/users/${username}/follow`),
}

// ─── Ads ─────────────────────────────────────────────
export const adsApi = {
  create: (data: FormData) =>
    api.post('/ads', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  getMyAds: () => api.get('/ads/mine'),
  pay: (adId: string, method: 'gopay' | 'googlepay') =>
    api.post(`/ads/${adId}/pay`, { method }),
}

// ─── Admin ───────────────────────────────────────────
export const adminApi = {
  getDashboard: () => api.get('/admin/dashboard'),
  getUsers: (page = 1, search = '') =>
    api.get(`/admin/users?page=${page}&search=${search}`),
  suspendUser: (userId: string) => api.post(`/admin/users/${userId}/suspend`),
  unsuspendUser: (userId: string) => api.post(`/admin/users/${userId}/unsuspend`),
  getLiveSessions: () => api.get('/admin/live'),
  stopLive: (streamId: string) => api.post(`/admin/live/${streamId}/stop`),
  updateFees: (fees: Record<string, number>) => api.put('/admin/fees', fees),
  getWithdrawRequests: () => api.get('/admin/withdrawals'),
  approveWithdrawal: (id: string) => api.post(`/admin/withdrawals/${id}/approve`),
  rejectWithdrawal: (id: string) => api.post(`/admin/withdrawals/${id}/reject`),
  generateImage: (prompt: string, style: string) =>
    api.post('/admin/generate/image', { prompt, style }),
  generateVideo: (prompt: string, duration: number, resolution: string) =>
    api.post('/admin/generate/video', { prompt, duration, resolution }),
  aiAssistant: (prompt: string, history: Array<{ role: string; content: string }>) =>
    api.post('/admin/ai-assistant', { prompt, history }),
}
