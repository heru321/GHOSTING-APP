import { api } from './api'

export interface MusicTrack {
  id: string
  title: string
  artist?: string
  fileUrl: string
  duration: number
  coverUrl?: string
  isPublic: boolean
  source: 'upload' | 'library'
  usageCount: number
  mimeType: string
  user?: { username: string; displayName: string }
  createdAt: string
}

export const musicApi = {
  /** Ambil daftar musik (library publik + milik user) */
  list: (params?: { search?: string; source?: 'mine' | 'library' | '' }) =>
    api.get<{ music: MusicTrack[] }>('/music', { params }),

  /** Upload audio dari HP/komputer */
  upload: (
    file: File,
    meta: { title: string; artist?: string; isPublic?: boolean },
    onProgress?: (pct: number) => void
  ) => {
    const fd = new FormData()
    fd.append('audio', file)
    fd.append('title', meta.title)
    if (meta.artist) fd.append('artist', meta.artist)
    fd.append('isPublic', String(meta.isPublic ?? false))

    return api.post<{ music: MusicTrack; message: string }>('/music/upload', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: e => {
        if (onProgress && e.total) onProgress(Math.round((e.loaded / e.total) * 100))
      },
    })
  },

  /** Edit judul/artist/visibility */
  update: (id: string, data: { title?: string; artist?: string; isPublic?: boolean }) =>
    api.patch<{ music: MusicTrack }>(`/music/${id}`, data),

  /** Hapus musik milik user */
  delete: (id: string) => api.delete(`/music/${id}`),

  /** Increment pemakaian */
  markUsed: (id: string) => api.post(`/music/${id}/use`),
}

/** Format detik → "m:ss" */
export function formatDuration(secs: number): string {
  const m = Math.floor(secs / 60)
  const s = Math.floor(secs % 60)
  return `${m}:${String(s).padStart(2, '0')}`
}

/** Baca durasi file audio di browser */
export function getAudioDurationBrowser(file: File): Promise<number> {
  return new Promise((resolve) => {
    const audio = document.createElement('audio')
    const url = URL.createObjectURL(file)
    audio.src = url
    audio.addEventListener('loadedmetadata', () => {
      URL.revokeObjectURL(url)
      resolve(audio.duration)
    })
    audio.addEventListener('error', () => { URL.revokeObjectURL(url); resolve(0) })
  })
}
