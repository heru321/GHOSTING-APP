'use client'
import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { api } from '@/lib/api'
import Cookies from 'js-cookie'

interface User {
  id: string
  phone: string
  username: string
  displayName: string
  avatar?: string
  bio?: string
  isAdmin: boolean
  balanceMLC: number
  balanceMSC: number
  balanceRupiah: number
  followers: number
  following: number
  totalLikes: number
  isVerified: boolean
  phantomWallet?: string
  trustWallet?: string
  comingSoonUntil?: Date | null
  comingSoonVideoId?: string | null
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (phone: string) => Promise<void>
  verifyOTP: (phone: string, otp: string) => Promise<void>
  logout: () => void
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = Cookies.get('ghosting_token')
    if (token) refreshUser()
    else setLoading(false)
  }, [])

  async function login(phone: string) {
    await api.post('/auth/send-otp', { phone })
  }

  async function verifyOTP(phone: string, otp: string) {
    const { data } = await api.post('/auth/verify-otp', { phone, otp })
    Cookies.set('ghosting_token', data.token, { expires: 30 })
    api.defaults.headers.common['Authorization'] = `Bearer ${data.token}`
    setUser(data.user)
  }

  async function refreshUser() {
    try {
      const token = Cookies.get('ghosting_token')
      if (!token) return
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`
      const { data } = await api.get('/auth/me')
      setUser(data.user)
    } catch {
      Cookies.remove('ghosting_token')
    } finally {
      setLoading(false)
    }
  }

  function logout() {
    Cookies.remove('ghosting_token')
    delete api.defaults.headers.common['Authorization']
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, verifyOTP, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
