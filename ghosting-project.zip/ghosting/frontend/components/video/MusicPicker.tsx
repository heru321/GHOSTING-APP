'use client'
import { useState, useRef, useEffect, useCallback } from 'react'
import { musicApi, MusicTrack, formatDuration, getAudioDurationBrowser } from '@/lib/musicApi'
import { toast } from 'react-toastify'

interface Props {
  selected: MusicTrack | null
  onSelect: (track: MusicTrack) => void
  musicVolume: number
  origVolume: number
  onMusicVolChange: (v: number) => void
  onOrigVolChange: (v: number) => void
}

type Tab = 'library' | 'mine' | 'upload'

const GHOST_LIBRARY: MusicTrack[] = [
  { id: 'lib-1', title: 'Ghostly Ambience', artist: 'Ghosting Originals', fileUrl: '', duration: 154, isPublic: true, source: 'library', usageCount: 12400, mimeType: 'audio/mpeg', createdAt: '' },
  { id: 'lib-2', title: 'Dark Forest Sounds', artist: 'Horror Pack', fileUrl: '', duration: 118, isPublic: true, source: 'library', usageCount: 8900, mimeType: 'audio/mpeg', createdAt: '' },
  { id: 'lib-3', title: 'EMF Static Noise', artist: 'Ghost Tools', fileUrl: '', duration: 45, isPublic: true, source: 'library', usageCount: 6200, mimeType: 'audio/mpeg', createdAt: '' },
  { id: 'lib-4', title: 'Shortwave Radio Scan', artist: 'Ghostbox Pack', fileUrl: '', duration: 72, isPublic: true, source: 'library', usageCount: 5100, mimeType: 'audio/mpeg', createdAt: '' },
  { id: 'lib-5', title: 'Cinematic Choir', artist: 'Soundtrack Pack', fileUrl: '', duration: 200, isPublic: true, source: 'library', usageCount: 9800, mimeType: 'audio/mpeg', createdAt: '' },
  { id: 'lib-6', title: 'Haunted Piano', artist: 'Ghost Keys', fileUrl: '', duration: 180, isPublic: true, source: 'library', usageCount: 7300, mimeType: 'audio/mpeg', createdAt: '' },
  { id: 'lib-orig', title: 'Audio Asli Video', artist: 'Ghosting Enhance ON', fileUrl: 'original', duration: 0, isPublic: true, source: 'library', usageCount: 0, mimeType: 'audio/mpeg', createdAt: '' },
]

const TRACK_COLORS: Record<string, string> = {
  'lib-1': '#7f77dd', 'lib-2': '#1d9e75', 'lib-3': '#ef4444',
  'lib-4': '#fbbf24', 'lib-5': '#3b82f6', 'lib-6': '#ec4899', 'lib-orig': '#6b7280',
}

export default function MusicPicker({ selected, onSelect, musicVolume, origVolume, onMusicVolChange, onOrigVolChange }: Props) {
  const [tab, setTab] = useState<Tab>('library')
  const [search, setSearch] = useState('')
  const [myMusic, setMyMusic] = useState<MusicTrack[]>([])
  const [loadingMine, setLoadingMine] = useState(false)
  const [previewId, setPreviewId] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  // Upload state
  const [dragOver, setDragOver] = useState(false)
  const [uploadFile, setUploadFile] = useState<File | null>(null)
  const [uploadMeta, setUploadMeta] = useState({ title: '', artist: '', isPublic: false })
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploading, setUploading] = useState(false)
  const [uploadedDuration, setUploadedDuration] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (tab === 'mine') fetchMyMusic()
  }, [tab])

  async function fetchMyMusic() {
    setLoadingMine(true)
    try {
      const { data } = await musicApi.list({ source: 'mine' })
      setMyMusic(data.music)
    } catch {
      toast.error('Gagal memuat musik kamu')
    } finally {
      setLoadingMine(false)
    }
  }

  function handlePreview(track: MusicTrack) {
    if (!track.fileUrl || track.fileUrl === 'original') return
    if (previewId === track.id) {
      audioRef.current?.pause()
      setPreviewId(null)
      return
    }
    if (audioRef.current) audioRef.current.pause()
    const audio = new Audio(track.fileUrl)
    audio.volume = 0.6
    audio.play().catch(() => {})
    audio.onended = () => setPreviewId(null)
    audioRef.current = audio
    setPreviewId(track.id)
  }

  function handleSelect(track: MusicTrack) {
    onSelect(track)
    if (track.id !== 'lib-orig') musicApi.markUsed(track.id).catch(() => {})
  }

  // ─── Drag & Drop + File Input ──────────────────────
  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    if (file) await prepareUploadFile(file)
  }, [])

  async function prepareUploadFile(file: File) {
    const allowed = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/aac', 'audio/flac', 'audio/x-m4a', 'audio/mp4']
    if (!allowed.includes(file.type)) {
      toast.error('Format tidak didukung. Gunakan MP3, WAV, AAC, OGG, atau FLAC.')
      return
    }
    if (file.size > 30 * 1024 * 1024) {
      toast.error('Ukuran file maksimal 30 MB')
      return
    }
    const dur = await getAudioDurationBrowser(file)
    if (dur > 900) {
      toast.error('Durasi maksimal 15 menit')
      return
    }
    setUploadFile(file)
    setUploadedDuration(dur)
    setUploadMeta(prev => ({
      ...prev,
      title: file.name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' '),
    }))
  }

  async function handleUpload() {
    if (!uploadFile || !uploadMeta.title.trim()) {
      toast.error('Isi judul musik dulu')
      return
    }
    setUploading(true)
    setUploadProgress(0)
    try {
      const { data } = await musicApi.upload(uploadFile, uploadMeta, setUploadProgress)
      toast.success('🎵 Musik berhasil diupload!')
      setMyMusic(prev => [data.music, ...prev])
      setUploadFile(null)
      setUploadMeta({ title: '', artist: '', isPublic: false })
      setUploadProgress(0)
      handleSelect(data.music)
      setTab('mine')
    } catch (err: any) {
      toast.error(err?.response?.data?.error || 'Gagal upload musik')
    } finally {
      setUploading(false)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Hapus musik ini?')) return
    try {
      await musicApi.delete(id)
      setMyMusic(prev => prev.filter(m => m.id !== id))
      if (selected?.id === id) onSelect(GHOST_LIBRARY[0])
      toast.success('Musik dihapus')
    } catch {
      toast.error('Gagal menghapus')
    }
  }

  const libraryFiltered = GHOST_LIBRARY.filter(t =>
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    (t.artist || '').toLowerCase().includes(search.toLowerCase())
  )
  const mineFiltered = myMusic.filter(t =>
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    (t.artist || '').toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="flex flex-col gap-0 h-full">
      {/* Tab switcher */}
      <div className="flex gap-0 mb-2 bg-white/5 rounded-lg overflow-hidden">
        {([['library', '🎵 Library'], ['mine', '📁 Milikku'], ['upload', '⬆️ Upload']] as [Tab, string][]).map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-2 text-[10px] transition-all font-medium ${tab === t ? 'bg-[#7f77dd] text-white' : 'text-white/50 hover:text-white/80'}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Search (library + mine) */}
      {tab !== 'upload' && (
        <div className="flex items-center gap-1.5 bg-white/7 border border-white/12 rounded-lg px-2.5 py-1.5 mb-2">
          <span className="text-[11px] text-white/40">🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Cari musik..." className="flex-1 bg-transparent outline-none text-[11px] text-white placeholder:text-white/30" />
        </div>
      )}

      {/* ── LIBRARY ── */}
      {tab === 'library' && (
        <div className="flex-1 overflow-y-auto flex flex-col gap-1">
          {libraryFiltered.map(track => (
            <TrackRow
              key={track.id} track={track}
              isSelected={selected?.id === track.id}
              isPreviewing={previewId === track.id}
              color={TRACK_COLORS[track.id] || '#7f77dd'}
              onSelect={() => handleSelect(track)}
              onPreview={() => handlePreview(track)}
            />
          ))}
        </div>
      )}

      {/* ── MILIKKU ── */}
      {tab === 'mine' && (
        <div className="flex-1 overflow-y-auto">
          {loadingMine ? (
            <div className="text-center py-6 text-[11px] text-white/40">Memuat...</div>
          ) : mineFiltered.length === 0 ? (
            <div className="text-center py-6">
              <div className="text-2xl mb-2">🎵</div>
              <div className="text-[11px] text-white/40 mb-3">Belum ada musik.</div>
              <button onClick={() => setTab('upload')} className="text-[11px] text-[#7f77dd] underline">Upload sekarang →</button>
            </div>
          ) : (
            <div className="flex flex-col gap-1">
              {mineFiltered.map(track => (
                <TrackRow
                  key={track.id} track={track}
                  isSelected={selected?.id === track.id}
                  isPreviewing={previewId === track.id}
                  color="#7f77dd"
                  onSelect={() => handleSelect(track)}
                  onPreview={() => handlePreview(track)}
                  onDelete={() => handleDelete(track.id)}
                  showDelete
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── UPLOAD ── */}
      {tab === 'upload' && (
        <div className="flex-1 overflow-y-auto flex flex-col gap-2">
          {/* Drop zone */}
          {!uploadFile ? (
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true) }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-5 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all min-h-[120px] ${dragOver ? 'border-[#7f77dd] bg-[rgba(127,119,221,0.12)]' : 'border-white/15 hover:border-white/30'}`}
            >
              <div className="text-3xl">🎵</div>
              <div className="text-[11px] text-white/70 text-center font-medium">Ketuk atau seret file musik ke sini</div>
              <div className="text-[10px] text-white/35 text-center">MP3 · WAV · AAC · OGG · FLAC · M4A<br />Maks. 30 MB · Maks. 15 menit</div>
              <input ref={fileInputRef} type="file" accept="audio/*,.mp3,.wav,.aac,.ogg,.flac,.m4a" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) prepareUploadFile(f) }} />
            </div>
          ) : (
            // File preview + metadata form
            <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col gap-2">
              {/* File info */}
              <div className="flex items-center gap-2 bg-[rgba(127,119,221,0.15)] border border-[rgba(127,119,221,0.3)] rounded-lg px-3 py-2">
                <span className="text-xl">🎵</span>
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-medium text-[#afa9ec] truncate">{uploadFile.name}</div>
                  <div className="text-[9px] text-white/40">
                    {(uploadFile.size / 1024 / 1024).toFixed(1)} MB
                    {uploadedDuration > 0 && ` · ${formatDuration(uploadedDuration)}`}
                  </div>
                </div>
                <button onClick={() => { setUploadFile(null); setUploadProgress(0) }} className="text-white/40 hover:text-white text-sm">✕</button>
              </div>

              {/* Waveform visualizer (decorative) */}
              <div className="flex items-center gap-0.5 h-6 px-1">
                {Array(40).fill(0).map((_, i) => (
                  <div key={i} className="w-1 rounded-sm bg-[#7f77dd] opacity-60"
                    style={{ height: `${Math.floor(Math.random() * 80 + 20)}%` }} />
                ))}
              </div>

              {/* Judul */}
              <div>
                <div className="text-[10px] text-white/40 mb-1">Judul *</div>
                <input value={uploadMeta.title} onChange={e => setUploadMeta(p => ({ ...p, title: e.target.value }))}
                  placeholder="Judul musik..."
                  className="w-full bg-white/7 border border-white/15 rounded-lg px-2.5 py-2 text-[11px] text-white outline-none focus:border-[#7f77dd]" />
              </div>

              {/* Artis */}
              <div>
                <div className="text-[10px] text-white/40 mb-1">Artis / Sumber (opsional)</div>
                <input value={uploadMeta.artist} onChange={e => setUploadMeta(p => ({ ...p, artist: e.target.value }))}
                  placeholder="Nama artis atau sumber..."
                  className="w-full bg-white/7 border border-white/15 rounded-lg px-2.5 py-2 text-[11px] text-white outline-none focus:border-[#7f77dd]" />
              </div>

              {/* Visibilitas */}
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input type="checkbox" checked={uploadMeta.isPublic}
                  onChange={e => setUploadMeta(p => ({ ...p, isPublic: e.target.checked }))}
                  className="accent-[#7f77dd] w-3.5 h-3.5" />
                <span className="text-[11px] text-white/70">Bagikan ke library publik Ghosting</span>
              </label>

              {/* Upload progress */}
              {uploading && (
                <div>
                  <div className="flex justify-between text-[10px] text-white/40 mb-1">
                    <span>Mengupload...</span><span>{uploadProgress}%</span>
                  </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }} />
                  </div>
                </div>
              )}

              {/* Tombol */}
              <div className="flex gap-2 mt-1">
                <button onClick={() => { setUploadFile(null); setUploadMeta({ title: '', artist: '', isPublic: false }) }}
                  disabled={uploading}
                  className="flex-1 py-2 border border-white/15 rounded-lg text-[11px] text-white/60 hover:bg-white/5 disabled:opacity-40">
                  Batal
                </button>
                <button onClick={handleUpload} disabled={uploading || !uploadMeta.title.trim()}
                  className="flex-1 py-2 bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-lg text-[11px] font-medium disabled:opacity-40">
                  {uploading ? `${uploadProgress}%` : '⬆️ Upload'}
                </button>
              </div>
            </div>
          )}

          {/* Tips */}
          <div className="bg-white/4 rounded-lg p-2.5 text-[10px] text-white/40 leading-5">
            💡 <strong className="text-white/60">Tips:</strong> Gunakan musik bebas royalti atau milikmu sendiri.
            Musik yang diupload bisa dipakai ulang di video lain. Jika dibagikan ke publik, user lain bisa pakai musikmu.
          </div>
        </div>
      )}

      {/* Volume sliders — selalu tampil */}
      {selected && (
        <div className="border-t border-white/7 pt-2 mt-2 flex flex-col gap-2">
          <SliderRow label="🎵 Volume Musik" value={`${musicVolume}%`}>
            <input type="range" min={0} max={100} value={musicVolume}
              onChange={e => onMusicVolChange(Number(e.target.value))}
              className="w-full accent-[#7f77dd] h-1" />
          </SliderRow>
          <SliderRow label="🔊 Suara Asli Video" value={`${origVolume}%`}>
            <input type="range" min={0} max={100} value={origVolume}
              onChange={e => onOrigVolChange(Number(e.target.value))}
              className="w-full accent-[#7f77dd] h-1" />
          </SliderRow>
        </div>
      )}
    </div>
  )
}

// ─── TrackRow sub-component ──────────────────────────
function TrackRow({
  track, isSelected, isPreviewing, color, onSelect, onPreview, onDelete, showDelete,
}: {
  track: MusicTrack; isSelected: boolean; isPreviewing: boolean
  color: string; onSelect: () => void; onPreview: () => void
  onDelete?: () => void; showDelete?: boolean
}) {
  return (
    <div
      onClick={onSelect}
      className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors ${isSelected ? 'bg-[rgba(127,119,221,0.18)]' : 'hover:bg-white/5'}`}
    >
      {/* Disc */}
      <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm flex-shrink-0"
        style={{ background: `${color}33`, border: `1px solid ${color}55` }}>
        {track.fileUrl === 'original' ? '🎤' : '♪'}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className={`text-[11px] truncate ${isSelected ? 'text-[#afa9ec]' : 'text-white/80'}`}>{track.title}</div>
        <div className="text-[9px] text-white/35 truncate">
          {track.artist || 'Unknown'}
          {track.duration > 0 && ` · ${formatDuration(track.duration)}`}
          {track.usageCount > 0 && ` · ${track.usageCount.toLocaleString()}x`}
        </div>
      </div>

      {/* Waveform bars jika playing */}
      {isPreviewing && (
        <div className="flex gap-0.5 items-center flex-shrink-0">
          {Array(5).fill(0).map((_, i) => (
            <div key={i} className="w-0.5 rounded-sm"
              style={{ background: color, height: 8, animation: `audiobar 0.5s ease-in-out ${i * 0.1}s infinite` }} />
          ))}
        </div>
      )}

      {/* Play preview button */}
      {track.fileUrl && track.fileUrl !== 'original' && (
        <button onClick={e => { e.stopPropagation(); onPreview() }}
          className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-[10px] flex-shrink-0 hover:bg-white/20 transition-colors">
          {isPreviewing ? '⏹' : '▶'}
        </button>
      )}

      {/* Check mark */}
      {isSelected && <span className="text-[#7f77dd] text-xs flex-shrink-0">✓</span>}

      {/* Delete button (my music) */}
      {showDelete && onDelete && (
        <button onClick={e => { e.stopPropagation(); onDelete() }}
          className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] text-red-400/60 hover:text-red-400 hover:bg-red-400/10 transition-colors flex-shrink-0">
          🗑
        </button>
      )}
    </div>
  )
}

function SliderRow({ label, value, children }: { label: string; value: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex justify-between text-[10px] text-white/40 mb-1">
        <span>{label}</span><span>{value}</span>
      </div>
      {children}
    </div>
  )
}
