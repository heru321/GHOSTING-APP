/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        ghost: {
          purple: '#7f77dd',
          dark: '#534ab7',
          deep: '#3c3489',
          teal: '#1d9e75',
          bg: '#0a0a0a',
          surface: '#111118',
          border: 'rgba(255,255,255,0.08)',
        },
      },
      fontFamily: { sans: ['Inter', 'sans-serif'] },
    },
  },
  plugins: [],
}
