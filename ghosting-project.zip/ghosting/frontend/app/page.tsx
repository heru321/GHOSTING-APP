'use client'
import { useState, useEffect, useRef } from 'react'
import { useSocket } from '@/components/SocketProvider'
import { videoApi } from '@/lib/api'
import { useAuth } from '@/components/AuthProvider'
import Link from 'next/link'

interface Video {
  id: string
  url: string
  thumbnail: string
  title: string
  description: string
  hashtags: string[]
  likes: number
  comments: number
  shares: number
  isLiked: boolean
  audioTitle: string
  ghostEffects: string[]
  is360: boolean
  user: { username: string; displayName: string; avatar?: string; isLive: boolean }
}

export default function FYPPage() {
  const { user } = useAuth()
  const socket = useSocket()
  const [videos, setVideos] = useState<Video[]>([])
  const [activeTab, setActiveTab] = useState<'fyp' | 'following' | 'live'>('fyp')
  const [currentIdx, setCurrentIdx] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => { loadVideos() }, [activeTab])

  async function loadVideos() {
    try {
      const { data } = await videoApi.getFYP()
      setVideos(data.videos)
    } catch (e) {
      // fallback to mock for dev
      setVideos(MOCK_VIDEOS)
    }
  }

  async function handleLike(videoId: string) {
    await videoApi.like(videoId)
    setVideos(prev => prev.map(v =>
      v.id === videoId ? { ...v, likes: v.isLiked ? v.likes - 1 : v.likes + 1, isLiked: !v.isLiked } : v
    ))
  }

  return (
    <div className="h-screen bg-black overflow-hidden">
      {/* Top nav */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-4 pt-10 pb-3 bg-gradient-to-b from-black/70 to-transparent">
        <Link href="/upload" className="text-white/70 text-sm">Live</Link>
        <div className="flex gap-5">
          {(['live', 'fyp', 'following'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`text-sm pb-1 border-b-2 transition-all capitalize ${
                activeTab === tab ? 'text-white border-white font-medium' : 'text-white/50 border-transparent'
              }`}
            >
              {tab === 'fyp' ? 'For You' : tab === 'live' ? 'LIVE' : 'Following'}
            </button>
          ))}
        </div>
        <Link href="/upload" className="text-white/70 text-sm">🔍</Link>
      </div>

      {/* Feed */}
      <div ref={containerRef} className="feed-container h-screen w-full">
        {videos.map((video, idx) => (
          <VideoCard
            key={video.id}
            video={video}
            isActive={idx === currentIdx}
            onLike={() => handleLike(video.id)}
          />
        ))}
      </div>

      {/* Bottom nav */}
      <BottomNav active="home" />
    </div>
  )
}

function VideoCard({ video, isActive, onLike }: { video: Video; isActive: boolean; onLike: () => void }) {
  return (
    <div className="feed-item relative h-screen w-full overflow-hidden bg-black">
      {/* Video background */}
      <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-[#1a0a2e] to-[#0a1a1a]">
        <span className="text-8xl opacity-30">👻</span>
      </div>

      {/* Ghost effects overlay */}
      {video.ghostEffects?.length > 0 && (
        <div className="absolute top-20 left-3 z-10 flex flex-col gap-1">
          {video.ghostEffects.map(fx => (
            <span key={fx} className="text-[10px] bg-[rgba(127,119,221,0.3)] border border-[rgba(127,119,221,0.5)] rounded-lg px-2 py-1 text-[#afa9ec]">
              {fx}
            </span>
          ))}
        </div>
      )}

      {/* Right actions */}
      <div className="absolute right-3 bottom-24 flex flex-col gap-4 items-center z-10">
        <Link href={`/profile/${video.user.username}`} className="flex flex-col items-center gap-1">
          <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#7f77dd] to-[#534ab7] flex items-center justify-center text-sm font-medium border-2 border-white">
            {video.user.displayName[0]}
          </div>
          <span className="text-xs text-white/70">Profile</span>
        </Link>
        <button onClick={onLike} className="flex flex-col items-center gap-1">
          <div className={`w-11 h-11 rounded-full flex items-center justify-center text-xl ${video.isLiked ? 'text-red-500' : 'text-white'}`}>
            ♥
          </div>
          <span className="text-xs text-white/80">{formatNum(video.likes)}</span>
        </button>
        <button className="flex flex-col items-center gap-1">
          <div className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-xl">💬</div>
          <span className="text-xs text-white/80">{formatNum(video.comments)}</span>
        </button>
        <button className="flex flex-col items-center gap-1">
          <div className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-xl">↗</div>
          <span className="text-xs text-white/80">Share</span>
        </button>
      </div>

      {/* Bottom info */}
      <div className="absolute bottom-20 left-0 right-16 px-4 z-10">
        <div className="flex items-center gap-2 mb-2">
          <span className="font-medium text-sm">@{video.user.username}</span>
          {video.user.isLive && (
            <span className="text-[10px] bg-red-500/80 rounded-full px-2 py-0.5 flex items-center gap-1">
              <span className="live-dot w-1.5 h-1.5 rounded-full bg-white inline-block" />LIVE
            </span>
          )}
          <span className="text-xs bg-[rgba(127,119,221,0.25)] border border-[rgba(127,119,221,0.4)] rounded-full px-2 py-0.5 text-[#afa9ec]">MLC</span>
        </div>
        <p className="text-sm text-white/85 mb-1">{video.description}</p>
        <p className="text-xs text-[#9f9bdd] mb-2">{video.hashtags.map(h => `#${h}`).join(' ')}</p>
        <div className="flex items-center gap-2 text-xs text-white/60">
          <div className="w-5 h-5 rounded-full bg-gradient-to-br from-gray-700 to-black border border-white/30 flex items-center justify-center text-[8px] animate-spin">♪</div>
          {video.audioTitle}
        </div>
      </div>
    </div>
  )
}

function BottomNav({ active }: { active: string }) {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-20 flex justify-around items-center py-2.5 pb-6 bg-[#111] border-t border-white/8">
      {[
        { id: 'home', icon: '🏠', label: 'Home', href: '/' },
        { id: 'discover', icon: '🔍', label: 'Discover', href: '/discover' },
        { id: 'upload', icon: null, label: '', href: '/upload' },
        { id: 'inbox', icon: '💬', label: 'Inbox', href: '/inbox' },
        { id: 'profile', icon: '👤', label: 'Profile', href: '/profile/me' },
      ].map(nav => (
        <Link key={nav.id} href={nav.href} className={`flex flex-col items-center gap-1 text-xs ${active === nav.id ? 'text-white' : 'text-white/45'}`}>
          {nav.icon
            ? <span className="text-xl">{nav.icon}</span>
            : <div className="w-11 h-7 bg-gradient-to-r from-[#7f77dd] to-[#1d9e75] rounded-lg flex items-center justify-center text-lg text-white font-light">+</div>
          }
          {nav.label && <span>{nav.label}</span>}
        </Link>
      ))}
    </div>
  )
}

function formatNum(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K'
  return String(n)
}

const MOCK_VIDEOS: Video[] = [
  { id: '1', url: '', thumbnail: '', title: 'Gedung Tua', description: 'Hunting malam di gedung tua — thermal cam nangkep sesuatu di sudut...', hashtags: ['ghosthunting', 'thermal', 'misterijabar'], likes: 182000, comments: 4200, shares: 1300, isLiked: false, audioTitle: 'Audio diperjelas — Ghosting Surround', ghostEffects: ['🌙 Night Vision', '🌡️ Thermal'], is360: false, user: { username: 'hantu_urban', displayName: 'Hantu Urban', isLive: true } },
  { id: '2', url: '', thumbnail: '', title: 'Hutan Angker', description: 'Live dari hutan angker — stick people kamera aktif!', hashtags: ['haunted', 'stickpeople', 'emf'], likes: 97300, comments: 1800, shares: 890, isLiked: false, audioTitle: 'Ghostbox Shortwave aktif', ghostEffects: ['🦴 Stick People', '⚡ EMF'], is360: true, user: { username: 'misteri_jawa', displayName: 'Misteri Jawa', isLive: false } },
]
