'use client'
import { useState, useRef, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { videoApi } from '@/lib/api'
import { toast } from 'react-toastify'
import MusicPicker from '@/components/video/MusicPicker'
import type { MusicTrack } from '@/lib/musicApi'

type EditorTab = 'trim' | 'filter' | 'text' | 'sticker' | 'music' | 'adjust'
type TextLayer = { id: string; text: string; color: string; style: string; x: number; y: number }
type StickerLayer = { id: string; emoji: string; x: number; y: number }

const FILTERS = [
  { id: 'ghost', label: 'Ghost', bg: 'from-[#1a0a2e] to-[#0d1a3a]', filter: 'brightness(0.8) saturate(0.7)' },
  { id: 'night', label: 'Night', bg: 'from-[#001a00] to-[#001000]', filter: 'brightness(3) contrast(1.4) saturate(0) hue-rotate(100deg)' },
  { id: 'thermal', label: 'Thermal', bg: 'from-[#1a0000] to-[#200800]', filter: 'sepia(0.5) hue-rotate(-30deg) contrast(1.2)' },
  { id: 'bw', label: 'B&W', bg: 'from-gray-900 to-gray-800', filter: 'grayscale(1) contrast(1.1)' },
  { id: 'cinematic', label: 'Cinematic', bg: 'from-[#0d1a3a] to-[#1a0a2e]', filter: 'contrast(1.2) brightness(0.9) saturate(1.3)' },
]

const STICKERS = ['👻', '😱', '⚡', '💀', '🌙', '🕯️', '📡', '🔦', '🌡️', '🏚️', '🌲', '🪬', '👁️', '〰️', '🦴', '🔮']

export default function VideoEditorPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<EditorTab>('trim')
  const [activeFilter, setActiveFilter] = useState('ghost')
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(35)
  const [texts, setTexts] = useState<TextLayer[]>([])
  const [stickers, setStickers] = useState<StickerLayer[]>([])
  const DEFAULT_TRACK: MusicTrack = { id: 'lib-1', title: 'Ghostly Ambience', artist: 'Ghosting Originals', fileUrl: '', duration: 154, isPublic: true, source: 'library', usageCount: 12400, mimeType: 'audio/mpeg', createdAt: '' }
  const [selectedMusic, setSelectedMusic] = useState<MusicTrack>(DEFAULT_TRACK)
  const [musicVol, setMusicVol] = useState(80)
  const [origVol, setOrigVol] = useState(60)
  const [brightness, setBrightness] = useState(0)
  const [contrast, setContrast] = useState(0)
  const [saturate, setSaturate] = useState(0)
  const [speed, setSpeed] = useState(10)
  const [textInput, setTextInput] = useState('')
  const [textColor, setTextColor] = useState('#ffffff')
  const [textStyle, setTextStyle] = useState('normal')
  const [isPosting, setIsPosting] = useState(false)
  const [showComingSoonModal, setShowComingSoonModal] = useState(false)
  const [comingSoonDur, setComingSoonDur] = useState<'1d' | '1w' | '1m'>('1w')
  const playRef = useRef<NodeJS.Timeout | null>(null)

  const filterStyle = FILTERS.find(f => f.id === activeFilter)

  useEffect(() => {
    if (playing) {
      playRef.current = setInterval(() => {
        setProgress(p => {
          if (p >= 100) { setPlaying(false); return 0 }
          return p + 0.3
        })
      }, 100)
    } else if (playRef.current) {
      clearInterval(playRef.current)
    }
    return () => { if (playRef.current) clearInterval(playRef.current) }
  }, [playing])

  function addText() {
    if (!textInput.trim()) return
    setTexts(prev => [...prev, {
      id: Date.now().toString(),
      text: textInput,
      color: textColor,
      style: textStyle,
      x: 50, y: 20,
    }])
    setTextInput('')
  }

  function addSticker(emoji: string) {
    setStickers(prev => [...prev, {
      id: Date.now().toString(),
      emoji, x: 50, y: 50,
    }])
  }

  async function handlePost(asComingSoon = false) {
    setIsPosting(true)
    try {
      // In real app: upload the edited video file + metadata
      const videoId = 'demo-' + Date.now()
      if (asComingSoon) {
        await videoApi.setComingSoon(videoId, comingSoonDur)
        toast.success('Video diupload & disematkan sebagai Coming Soon di profil!')
      } else {
        toast.success('Video berhasil dipost ke FYP!')
      }
      setTimeout(() => router.push('/'), 1500)
    } catch {
      toast.error('Gagal mengupload video.')
    } finally {
      setIsPosting(false)
      setShowComingSoonModal(false)
    }
  }

  const filterCss = `brightness(${1 + brightness / 100}) contrast(${1 + contrast / 100}) saturate(${1 + saturate / 100}) ${FILTERS.find(f => f.id === activeFilter)?.filter || ''}`

  return (
    <div className="h-screen bg-[#0a0a0a] flex text-white overflow-hidden">
      {/* PREVIEW */}
      <div className="w-[200px] flex-shrink-0 relative bg-[#0d0d1a] border-r border-white/8">
        <div className={`absolute inset-0 bg-gradient-to-br ${filterStyle?.bg || 'from-[#1a0a2e] to-[#0d1a3a]'}`} style={{ filter: filterCss }}>
          <div className="flex items-center justify-center h-full text-7xl opacity-30">👻</div>
        </div>

        {/* Text layers */}
        {texts.map(t => (
          <div key={t.id} className="absolute text-sm font-medium px-2 py-0.5 rounded cursor-move"
            style={{ color: t.color, top: `${t.y}%`, left: `${t.x}%`, transform: 'translateX(-50%)',
              textShadow: t.style === 'glow' ? `0 0 10px ${t.color}` : undefined,
              background: t.style === 'bg' ? 'rgba(127,119,221,0.8)' : undefined }}>
            {t.text}
          </div>
        ))}

        {/* Sticker layers */}
        {stickers.map(s => (
          <div key={s.id} className="absolute text-2xl cursor-move"
            style={{ top: `${s.y}%`, left: `${s.x}%`, transform: 'translate(-50%,-50%)' }}>
            {s.emoji}
          </div>
        ))}

        {/* Music bar */}
        {selectedMusic && (
          <div className="absolute bottom-10 left-0 right-0 bg-black/60 px-2 py-1.5 flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-gray-700 to-black border border-white/30 flex items-center justify-center text-[8px] animate-spin">♪</div>
            <span className="text-[10px] text-white/80 flex-1 truncate">{selectedMusic.title}</span>
          </div>
        )}

        {/* Top bar */}
        <div className="absolute top-0 left-0 right-0 px-2 py-2 flex items-center justify-between bg-gradient-to-b from-black/60 to-transparent z-10">
          <button onClick={() => router.back()} className="text-[10px] text-white/70 bg-white/10 rounded-md px-2 py-1">✕</button>
          <button onClick={() => {}} className="text-[10px] text-white/70 bg-white/10 rounded-md px-2 py-1">↩</button>
        </div>

        {/* Play bar */}
        <div className="absolute bottom-0 left-0 right-0 px-2 pb-2 flex items-center gap-2 bg-gradient-to-t from-black/60 to-transparent">
          <button onClick={() => setPlaying(p => !p)} className="w-6 h-6 rounded-full bg-white/15 flex items-center justify-center text-xs">
            {playing ? '⏸' : '▶'}
          </button>
          <div className="flex-1 h-0.5 bg-white/20 rounded cursor-pointer" onClick={e => {
            const r = e.currentTarget.getBoundingClientRect()
            setProgress(((e.clientX - r.left) / r.width) * 100)
          }}>
            <div className="h-full bg-[#7f77dd] rounded" style={{ width: `${progress}%` }} />
          </div>
          <span className="text-[9px] text-white/50">{Math.floor(progress * 0.92 / 100 * 60)}s</span>
        </div>
      </div>

      {/* TOOLS */}
      <div className="w-[190px] bg-[#0f0f13] border-r border-white/7 flex flex-col">
        <div className="flex border-b border-white/7 overflow-x-auto">
          {(['trim', 'filter', 'text', 'sticker', 'music', 'adjust'] as EditorTab[]).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 text-[10px] text-center border-b-2 transition-all min-w-[32px] ${activeTab === tab ? 'text-[#afa9ec] border-[#7f77dd]' : 'text-white/40 border-transparent'}`}>
              {tab === 'trim' ? '✂️' : tab === 'filter' ? '🎨' : tab === 'text' ? 'T' : tab === 'sticker' ? '😊' : tab === 'music' ? '♪' : '☀️'}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-2.5">
          {/* TRIM */}
          {activeTab === 'trim' && (
            <div>
              <div className="text-[10px] text-white/40 mb-2">Trim & Speed</div>
              <div className="h-10 bg-white/8 rounded-lg relative overflow-hidden mb-3 cursor-pointer">
                <div className="absolute inset-y-1 left-[10%] right-[20%] bg-[rgba(127,119,221,0.4)] border-l-2 border-r-2 border-[#7f77dd] rounded" />
                <div className="grid grid-cols-7 gap-0.5 p-0.5 h-full pointer-events-none">
                  {Array(7).fill(0).map((_, i) => <div key={i} className="bg-[rgba(127,119,221,0.15)] rounded-sm" />)}
                </div>
              </div>
              <SliderRow label="Kecepatan" value={`${(speed/10).toFixed(1)}x`}>
                <input type="range" min={5} max={20} value={speed} onChange={e => setSpeed(Number(e.target.value))} className="w-full accent-[#7f77dd]" />
              </SliderRow>
              {['✂️ Split di posisi ini', '⏪ Reverse video', '🔁 Loop video'].map(label => (
                <div key={label} className="flex items-center gap-2 px-2 py-2 rounded-lg text-[11px] text-white/60 hover:bg-[rgba(127,119,221,0.1)] cursor-pointer mb-1">{label}</div>
              ))}
            </div>
          )}

          {/* FILTER */}
          {activeTab === 'filter' && (
            <div>
              <div className="text-[10px] text-white/40 mb-2">Filter</div>
              <div className="flex gap-1.5 overflow-x-auto pb-1 mb-3">
                {FILTERS.map(f => (
                  <div key={f.id} className="flex-shrink-0 text-center cursor-pointer" onClick={() => setActiveFilter(f.id)}>
                    <div className={`w-12 h-16 rounded-md bg-gradient-to-br ${f.bg} flex items-center justify-center text-lg border-2 ${activeFilter === f.id ? 'border-[#7f77dd]' : 'border-transparent'}`}>👻</div>
                    <div className="text-[9px] text-white/50 mt-0.5">{f.label}</div>
                  </div>
                ))}
              </div>
              <SliderRow label="Brightness" value={String(brightness)}>
                <input type="range" min={-100} max={100} value={brightness} onChange={e => setBrightness(Number(e.target.value))} className="w-full accent-[#7f77dd]" />
              </SliderRow>
              <SliderRow label="Contrast" value={String(contrast)}>
                <input type="range" min={-100} max={100} value={contrast} onChange={e => setContrast(Number(e.target.value))} className="w-full accent-[#7f77dd]" />
              </SliderRow>
              <SliderRow label="Saturasi" value={String(saturate)}>
                <input type="range" min={-100} max={100} value={saturate} onChange={e => setSaturate(Number(e.target.value))} className="w-full accent-[#7f77dd]" />
              </SliderRow>
            </div>
          )}

          {/* TEXT */}
          {activeTab === 'text' && (
            <div>
              <div className="text-[10px] text-white/40 mb-2">Tambah Teks</div>
              <input value={textInput} onChange={e => setTextInput(e.target.value)}
                placeholder="Ketik teks..."
                className="w-full bg-white/7 border border-white/15 rounded-lg px-2.5 py-2 text-xs outline-none focus:border-[#7f77dd] mb-2" />
              <div className="flex gap-1.5 flex-wrap mb-3">
                {['#ffffff', '#afa9ec', '#ef4444', '#22c55e', '#fbbf24', '#38bdf8'].map(c => (
                  <div key={c} onClick={() => setTextColor(c)}
                    className={`w-5 h-5 rounded-full cursor-pointer border-2 ${textColor === c ? 'border-white scale-110' : 'border-transparent'}`}
                    style={{ background: c }} />
                ))}
              </div>
              {['normal', 'glow', 'bg', 'outline'].map(s => (
                <div key={s} onClick={() => setTextStyle(s)}
                  className={`text-xs px-2 py-1.5 rounded-md border cursor-pointer mb-1.5 ${textStyle === s ? 'border-[#7f77dd] bg-[rgba(127,119,221,0.15)]' : 'border-white/12'}`}>
                  {s === 'normal' ? 'Normal' : s === 'glow' ? '✨ Glow' : s === 'bg' ? '🟣 Kotak Warna' : '◻️ Outline'}
                </div>
              ))}
              <button onClick={addText} className="w-full mt-2 py-2 bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-lg text-xs font-medium">
                + Tambah ke Video
              </button>
            </div>
          )}

          {/* STICKER */}
          {activeTab === 'sticker' && (
            <div>
              <div className="text-[10px] text-white/40 mb-2">Stiker</div>
              <div className="grid grid-cols-4 gap-1.5">
                {STICKERS.map(s => (
                  <button key={s} onClick={() => addSticker(s)}
                    className="aspect-square text-xl flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* MUSIC — full MusicPicker dengan upload dari HP */}
          {activeTab === 'music' && (
            <div className="flex flex-col h-full">
              <MusicPicker
                selected={selectedMusic}
                onSelect={setSelectedMusic}
                musicVolume={musicVol}
                origVolume={origVol}
                onMusicVolChange={setMusicVol}
                onOrigVolChange={setOrigVol}
              />
            </div>
          )}

          {/* ADJUST */}
          {activeTab === 'adjust' && (
            <div>
              <div className="text-[10px] text-white/40 mb-2">☀️ Penyesuaian</div>
              {[{ label: 'Exposure', id: 'exp' }, { label: 'Highlights', id: 'hi' }, { label: 'Shadows', id: 'sh' }, { label: 'Warmth', id: 'warm' }].map(item => (
                <SliderRow key={item.id} label={item.label} value="0">
                  <input type="range" min={-100} max={100} defaultValue={0} className="w-full accent-[#7f77dd]" />
                </SliderRow>
              ))}
              <div className="text-[10px] text-white/40 mt-3 mb-2">🔊 Audio Enhance</div>
              {['🔊 Ghosting Surround ON', '🎚️ Noise Reduction', '📢 Amplify Quiet Sounds'].map(item => (
                <div key={item} className="flex items-center gap-2 px-2 py-2 rounded-lg text-[11px] bg-[rgba(127,119,221,0.1)] text-[#afa9ec] mb-1 cursor-pointer">{item}</div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* RIGHT: Timeline + Post */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-white/7">
          <span className="text-sm font-medium flex-1">📋 Timeline</span>
          <span className="text-xs text-white/40">Unsaved</span>
          <button onClick={() => setShowComingSoonModal(true)}
            className="px-3 py-1.5 bg-white/8 border border-white/15 rounded-lg text-xs text-white/70 hover:bg-white/15">
            🎬 Coming Soon
          </button>
          <button onClick={() => handlePost(false)} disabled={isPosting}
            className="px-4 py-1.5 bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-lg text-xs font-medium disabled:opacity-50">
            {isPosting ? 'Uploading...' : 'Post →'}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {/* Video track */}
          <div className="mb-4">
            <div className="text-[10px] text-white/35 tracking-wider mb-2">VIDEO CLIPS</div>
            <div className="h-12 bg-white/5 rounded-lg overflow-hidden relative">
              <div className="absolute inset-y-1 left-1 right-14 bg-gradient-to-r from-[rgba(127,119,221,0.4)] to-[rgba(83,74,183,0.4)] rounded-md flex items-center px-3 text-xs text-white/70">
                👻 Clip utama (0:00–1:32)
              </div>
              <div className="absolute right-1 top-1 bottom-1 flex gap-1 items-center">
                <div className="w-8 h-8 bg-white/10 rounded-md flex items-center justify-center text-xs cursor-pointer">✂️</div>
                <div className="w-8 h-8 bg-white/10 rounded-md flex items-center justify-center text-xs cursor-pointer">🗑️</div>
              </div>
            </div>
          </div>

          {/* Audio track */}
          <div className="mb-4">
            <div className="text-[10px] text-white/35 tracking-wider mb-2">AUDIO</div>
            <div className="h-9 bg-[rgba(29,158,117,0.15)] border border-[rgba(29,158,117,0.3)] rounded-lg flex items-center px-3 gap-2">
              <span className="text-sm">🎵</span>
              <span className="text-[11px] text-[rgba(29,158,117,0.9)] flex-1">{selectedMusic.title}</span>
              <div className="flex gap-0.5 items-center">
                {Array(8).fill(0).map((_, i) => (
                  <div key={i} className="w-0.5 bg-[rgba(29,158,117,0.7)] rounded audio-bar" style={{ height: 6, animationDelay: `${i * 0.1}s` }} />
                ))}
              </div>
            </div>
          </div>

          {/* Text tracks */}
          {texts.length > 0 && (
            <div className="mb-4">
              <div className="text-[10px] text-white/35 tracking-wider mb-2">TEKS</div>
              {texts.map(t => (
                <div key={t.id} className="h-9 bg-[rgba(127,119,221,0.1)] border border-[rgba(127,119,221,0.3)] rounded-lg flex items-center px-3 gap-2 mb-1.5">
                  <span className="text-sm">T</span>
                  <span className="text-[11px] text-[#afa9ec] flex-1">{t.text}</span>
                  <button onClick={() => setTexts(prev => prev.filter(x => x.id !== t.id))} className="text-white/40 text-xs hover:text-white">✕</button>
                </div>
              ))}
            </div>
          )}

          {/* Sticker tracks */}
          {stickers.length > 0 && (
            <div className="mb-4">
              <div className="text-[10px] text-white/35 tracking-wider mb-2">STIKER</div>
              {stickers.map(s => (
                <div key={s.id} className="h-9 bg-[rgba(250,200,0,0.06)] border border-[rgba(250,200,0,0.2)] rounded-lg flex items-center px-3 gap-2 mb-1.5">
                  <span>{s.emoji}</span>
                  <span className="text-[11px] text-white/60 flex-1">Stiker</span>
                  <button onClick={() => setStickers(prev => prev.filter(x => x.id !== s.id))} className="text-white/40 text-xs hover:text-white">✕</button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex gap-2 p-3 border-t border-white/7">
          <button onClick={() => toast.info('Tersimpan sebagai draft')} className="flex-1 py-2.5 border border-white/15 rounded-xl text-xs text-white/70 hover:bg-white/5">💾 Draft</button>
          <button className="flex-1 py-2.5 border border-white/15 rounded-xl text-xs text-white/70 hover:bg-white/5">👁️ Preview</button>
          <button onClick={() => setShowComingSoonModal(true)} className="flex-1 py-2.5 bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-xl text-xs font-medium">⬆️ Upload</button>
        </div>
      </div>

      {/* COMING SOON MODAL */}
      {showComingSoonModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-end">
          <div className="w-full bg-[#111118] rounded-t-2xl p-5">
            <div className="text-base font-medium mb-4">🎬 Upload sebagai Coming Soon?</div>
            <div className="bg-gradient-to-br from-[#1a0a2e] to-[#0d1a3a] rounded-xl p-4 mb-4 text-center">
              <div className="text-2xl mb-2">👻</div>
              <div className="text-sm font-medium tracking-widest border border-white/60 inline-block px-4 py-1 rounded mb-1">COMING SOON</div>
              <div className="text-[10px] text-white/50 tracking-widest">GHOSTING · @user</div>
            </div>
            <div className="text-xs text-white/50 mb-3">Pilih durasi tampil di profil:</div>
            <div className="flex gap-2 mb-4">
              {[['1d', '1 Hari'], ['1w', '1 Minggu'], ['1m', '1 Bulan']].map(([val, label]) => (
                <button key={val} onClick={() => setComingSoonDur(val as '1d' | '1w' | '1m')}
                  className={`flex-1 py-2 rounded-xl text-sm border transition-all ${comingSoonDur === val ? 'border-[#7f77dd] bg-[rgba(127,119,221,0.15)] text-[#afa9ec]' : 'border-white/15 text-white/60'}`}>
                  {label}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-white/40 text-center mb-4">
              Trailer AI akan tersemat di profil selama {comingSoonDur === '1d' ? '1 hari' : comingSoonDur === '1w' ? '1 minggu' : '1 bulan'}, lalu otomatis lepas.
            </p>
            <div className="flex gap-2">
              <button onClick={() => setShowComingSoonModal(false)} className="flex-1 py-3 border border-white/15 rounded-xl text-sm text-white/60">Batal</button>
              <button onClick={() => handlePost(true)} disabled={isPosting} className="flex-1 py-3 bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-xl text-sm font-medium disabled:opacity-50">
                {isPosting ? 'Uploading...' : '📌 Pin di Profil'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function SliderRow({ label, value, children }: { label: string; value: string; children: React.ReactNode }) {
  return (
    <div className="mb-3">
      <div className="flex justify-between text-[10px] text-white/50 mb-1">
        <span>{label}</span><span>{value}</span>
      </div>
      {children}
    </div>
  )
}
