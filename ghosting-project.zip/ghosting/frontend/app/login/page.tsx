'use client'
import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/AuthProvider'
import { toast } from 'react-toastify'

type Step = 'phone' | 'otp' | 'done'

export default function LoginPage() {
  const router = useRouter()
  const { login, verifyOTP } = useAuth()
  const [step, setStep] = useState<Step>('phone')
  const [phone, setPhone] = useState('')
  const [otp, setOtp] = useState(['', '', '', '', '', ''])
  const [loading, setLoading] = useState(false)
  const [countdown, setCountdown] = useState(0)
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])

  async function handleSendOTP() {
    if (phone.length < 9) return
    setLoading(true)
    try {
      await login(phone)
      setStep('otp')
      startCountdown()
      toast.success('Kode OTP dikirim!')
    } catch {
      toast.error('Gagal mengirim OTP. Coba lagi.')
    } finally {
      setLoading(false)
    }
  }

  async function handleVerify() {
    const code = otp.join('')
    if (code.length < 6) return
    setLoading(true)
    try {
      await verifyOTP('+62' + phone, code)
      setStep('done')
      setTimeout(() => router.push('/'), 1200)
    } catch {
      toast.error('Kode OTP salah atau kadaluarsa.')
    } finally {
      setLoading(false)
    }
  }

  function startCountdown() {
    setCountdown(59)
    const int = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { clearInterval(int); return 0 }
        return prev - 1
      })
    }, 1000)
  }

  function handleOtpChange(index: number, value: string) {
    if (!/^\d*$/.test(value)) return
    const next = [...otp]
    next[index] = value
    setOtp(next)
    if (value && index < 5) otpRefs.current[index + 1]?.focus()
  }

  function handleOtpKeyDown(index: number, e: React.KeyboardEvent) {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus()
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-ghost-bg p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-medium tracking-widest mb-1">
            Ghost<span className="text-[#7f77dd]">ing</span>
          </h1>
          <p className="text-sm text-white/40 tracking-widest">Dunia lain, ada di sini.</p>
        </div>

        {/* Card */}
        <div className="bg-[#111118] rounded-2xl border border-white/8 p-6">
          {step === 'phone' && (
            <>
              <h2 className="text-lg font-medium mb-1">Masuk atau Daftar</h2>
              <p className="text-sm text-white/50 mb-6">Masukkan nomor HP untuk mendapat kode OTP</p>
              <div className="flex gap-2 mb-5">
                <div className="flex items-center gap-2 bg-white/8 border border-white/15 rounded-xl px-3 py-3 text-sm">
                  🇮🇩 +62
                </div>
                <input
                  type="tel"
                  value={phone}
                  onChange={e => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="812 3456 7890"
                  className="flex-1 bg-white/7 border border-white/15 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#7f77dd] transition-colors"
                  maxLength={13}
                  onKeyDown={e => e.key === 'Enter' && handleSendOTP()}
                />
              </div>
              <button
                onClick={handleSendOTP}
                disabled={phone.length < 9 || loading}
                className="w-full py-3.5 bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-xl font-medium text-sm disabled:opacity-40 disabled:cursor-not-allowed transition-opacity"
              >
                {loading ? 'Mengirim...' : 'Kirim Kode OTP'}
              </button>
              <div className="flex items-center gap-3 my-4">
                <div className="flex-1 h-px bg-white/10" />
                <span className="text-xs text-white/35">atau</span>
                <div className="flex-1 h-px bg-white/10" />
              </div>
              <button className="w-full py-3 border border-white/15 rounded-xl text-sm text-white/70 hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
                👻 Connect Phantom / Trust Wallet
              </button>
            </>
          )}

          {step === 'otp' && (
            <>
              <button onClick={() => setStep('phone')} className="flex items-center gap-1 text-sm text-white/50 mb-5 hover:text-white transition-colors">
                ← Kembali
              </button>
              <h2 className="text-lg font-medium mb-1">Masukkan Kode OTP</h2>
              <p className="text-sm text-white/50 mb-6">
                Dikirim ke <strong className="text-white">+62 {phone}</strong>
              </p>
              <div className="flex gap-2 justify-center mb-6">
                {otp.map((digit, i) => (
                  <input
                    key={i}
                    ref={el => otpRefs.current[i] = el}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={e => handleOtpChange(i, e.target.value)}
                    onKeyDown={e => handleOtpKeyDown(i, e)}
                    className="w-11 h-14 text-center text-xl font-medium bg-white/7 border-2 border-white/15 rounded-xl outline-none focus:border-[#7f77dd] focus:bg-[rgba(127,119,221,0.12)] transition-all"
                  />
                ))}
              </div>
              <div className="text-center text-sm text-white/40 mb-5">
                {countdown > 0
                  ? <>Kirim ulang dalam <span className="text-[#7f77dd]">{countdown}s</span></>
                  : <button onClick={() => { handleSendOTP(); startCountdown() }} className="text-[#7f77dd]">Kirim ulang kode</button>
                }
              </div>
              <button
                onClick={handleVerify}
                disabled={otp.join('').length < 6 || loading}
                className="w-full py-3.5 bg-gradient-to-r from-[#534ab7] to-[#7f77dd] rounded-xl font-medium text-sm disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {loading ? 'Memverifikasi...' : 'Verifikasi'}
              </button>
            </>
          )}

          {step === 'done' && (
            <div className="text-center py-4">
              <div className="text-6xl mb-4">👻</div>
              <h2 className="text-xl font-medium mb-2">Selamat Datang!</h2>
              <p className="text-sm text-white/50">Masuk ke Ghosting...</p>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-white/30 mt-5">
          Dengan melanjutkan kamu menyetujui{' '}
          <span className="text-[#7f77dd] cursor-pointer">Syarat Layanan</span> Ghosting
        </p>
      </div>
    </div>
  )
}
