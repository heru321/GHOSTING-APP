import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/Providers'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Ghosting — Dunia Lain, Ada di Sini',
  description: 'Platform video pendek ghost hunting dengan Live, Marketplace, Token MLC & MSC',
  manifest: '/manifest.json',
  themeColor: '#0a0a0a',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className="dark">
      <body className={`${inter.className} bg-ghost-bg text-white min-h-screen`}>
        <Providers>
          {children}
          <ToastContainer
            theme="dark"
            position="top-center"
            toastStyle={{ background: '#111118', border: '1px solid rgba(127,119,221,0.3)' }}
          />
        </Providers>
      </body>
    </html>
  )
}
