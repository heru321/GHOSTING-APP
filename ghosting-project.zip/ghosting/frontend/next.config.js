/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { serverActions: true },
  images: {
    domains: ['localhost', 'ghosting-cdn.s3.ap-southeast-1.amazonaws.com'],
  },
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000',
    NEXT_PUBLIC_SOCKET_URL: process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:4000',
    NEXT_PUBLIC_MLC_TOKEN_ADDRESS: 'KuzqZjWBVPDq74ymZrHv6pG7v6FdwRtxbufzG6BStSq',
    NEXT_PUBLIC_MSC_TOKEN_ADDRESS: '6iWNyGr6pERkqJny6GiiR12PRw84UdX1G4n5bMuspump',
  },
}
module.exports = nextConfig
